"""
Generate self-signed certificate for miniC2
Run once before starting the server.
"""
import os
import subprocess
import sys

CERT_DIR = os.path.join(os.path.dirname(__file__), "..", "certs")

def main():
    os.makedirs(CERT_DIR, exist_ok=True)
    cert_file = os.path.join(CERT_DIR, "server.pem")
    key_file = os.path.join(CERT_DIR, "server.key")

    if os.path.exists(cert_file) and os.path.exists(key_file):
        print("[*] Certificates already exist. Delete them to regenerate.")
        return

    print("[*] Generating self-signed certificate...")

    # Try openssl first
    try:
        cmd = [
            "openssl", "req", "-x509", "-newkey", "rsa:2048",
            "-keyout", key_file,
            "-out", cert_file,
            "-days", "365", "-nodes",
            "-subj", "/C=US/ST=Test/L=Test/O=miniC2/CN=localhost"
        ]
        subprocess.run(cmd, check=True, capture_output=True)
        print(f"[+] Certificate generated:")
        print(f"    Cert: {cert_file}")
        print(f"    Key:  {key_file}")
        return
    except (subprocess.CalledProcessError, FileNotFoundError):
        pass

    # Fallback: use Python's built-in ssl tools
    try:
        from cryptography import x509
        from cryptography.x509.oid import NameOID
        from cryptography.hazmat.primitives import hashes, serialization
        from cryptography.hazmat.primitives.asymmetric import rsa
        import datetime

        key = rsa.generate_private_key(public_exponent=65537, key_size=2048)

        subject = issuer = x509.Name([
            x509.NameAttribute(NameOID.COUNTRY_NAME, "US"),
            x509.NameAttribute(NameOID.ORGANIZATION_NAME, "miniC2"),
            x509.NameAttribute(NameOID.COMMON_NAME, "localhost"),
        ])

        cert = (
            x509.CertificateBuilder()
            .subject_name(subject)
            .issuer_name(issuer)
            .public_key(key.public_key())
            .serial_number(x509.random_serial_number())
            .not_valid_before(datetime.datetime.utcnow())
            .not_valid_after(datetime.datetime.utcnow() + datetime.timedelta(days=365))
            .add_extension(x509.SubjectAlternativeName([x509.DNSName("localhost")]), critical=False)
            .sign(key, hashes.SHA256())
        )

        with open(key_file, "wb") as f:
            f.write(key.private_bytes(
                serialization.Encoding.PEM,
                serialization.PrivateFormat.TraditionalOpenSSL,
                serialization.NoEncryption()
            ))

        with open(cert_file, "wb") as f:
            f.write(cert.public_bytes(serialization.Encoding.PEM))

        print(f"[+] Certificate generated (cryptography library):")
        print(f"    Cert: {cert_file}")
        print(f"    Key:  {key_file}")
        return
    except ImportError:
        pass

    print("[!] Cannot generate certificates. Install openssl or 'cryptography' package:")
    print("    pip install cryptography")
    sys.exit(1)


if __name__ == "__main__":
    main()
