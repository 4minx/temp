@echo off
REM Build miniC2 Agent for Windows
REM Requires MSVC (Visual Studio) or MinGW

echo ===================================
echo  Building miniC2 Agent
echo ===================================

REM Try MSVC first
where cl >nul 2>&1
if %errorlevel%==0 (
    echo [*] Using MSVC
    cl /EHsc /O2 agent.cpp /Fe:agent.exe /link winhttp.lib advapi32.lib user32.lib user32.lib
    goto :done
)

REM Try MinGW
where g++ >nul 2>&1
if %errorlevel%==0 (
    echo [*] Using MinGW g++
    g++ -o agent.exe agent.cpp -lwinhttp -ladvapi32 -luser32 -lgdi32 -lole32 -luuid -lrpcrt4 -lws2_32 -static -O2
    goto :done
)

echo [!] No compiler found. Install Visual Studio or MinGW.
echo     MSVC: cl /EHsc agent.cpp /link winhttp.lib
echo     MinGW: g++ -o agent.exe agent.cpp -lwinhttp -ladvapi32 -luser32 -static

:done
if exist agent.exe (
    echo [+] Build successful: agent.exe
) else (
    echo [!] Build failed
)
